const dbConfig = require("./db-config");
var sql = require('mssql');
var logger = require("../logger/app-logger");

class DBHelper {
    //_dbConfig = null;
    constructor() {
        this._dbConfig = dbConfig.connectionSettings;
    };
    closeDBConnection(conObj) {
        conObj.close();
    }
    getConnectionString() {
        return new sql.ConnectionPool(this._dbConfig);
    }    
    async getUsageProjectionData() {
        try{
        let conn = this.getConnectionString();
        await conn.connect();
        var request = new sql.Request(conn);
        const result = await request.execute(dbConfig.storedProcedures.SP_GETUSAGEPROJECTION);        
        conn.close();
        return result.recordset;
        }
        catch (err) {
            logger.consoleLog(`error in getCALookupMasterData method : ${JSON.stringify(err.stack)}`);
        }
    }
   
}
module.exports = DBHelper;