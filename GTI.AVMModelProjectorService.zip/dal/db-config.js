var AppConfig = require("../config/app-config");

var dbConfig = {
    connectionSettings: AppConfig.DBConnectionSettings,
    storedProcedures:{        
        SP_GETUSAGEPROJECTION:'sp_GetUsageProjection',        
    }
}

module.exports = dbConfig;