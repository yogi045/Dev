var DBHelper = require('../dal/db-helper');
var AVMProjection = require('../Models/AVMProjection');
var logger = require('../logger/app-logger');

const { config } = require('winston');

var getDataFromDB = {      
    getAVMData: async function () {
            try {
            var objDBHelper = new DBHelper(); 
            var data = await objDBHelper.getUsageProjectionData();  
            // arrAVMProjected = [];
            // data.forEach(row =>{
            //         const obj = new AVMProjection.AVMProjection();
            //         obj.ServerName= row.ServerName,
            //         obj.ApplicationName= row.ApplicationName,
            //         obj.Contacts= row.Contacts,
            //         obj.Prediction= row.Prediction,
            //         obj.Current_Schedule_Hours= row.Current_Schedule_Hours,
            //         obj.Current_Utilized_Hours= row.Current_Utilized_Hours          
            //         arrAVMProjected.push(obj);
            // })
            // return arrAVMProjected;
            return data;
        }
        catch (ex) {        
            logger.logError(`error occored in getLookUpMaster method : ${ex}`);
        }      
    }
}
module.exports = getDataFromDB;