var fileSaver = require('./fileSaver/save-to-csv');
var winston = require('winston');
var AppConfig = require("../config/app-config");
const { createLogger, format, transports } = require('winston')

require('winston-daily-rotate-file');
var fs = require('fs');
const __folderName = AppConfig.LoggerFolderLocation;
var transport = new (winston.transports.DailyRotateFile)({
    filename: `${__folderName}/daily-log-%DATE%.log`,
    datePattern: 'YYYY-MM-DD',
    zippedArchive: true,
    maxSize: '10m',
    maxFiles: '14d',
    console: true,
    consoleLog: true
});
console.log(__folderName)
transport.on('rotate', function (oldFilename, newFilename) {
    // do something fun
});
var winstonLogger = winston.createLogger({
    format: format.combine(
        format.timestamp({
            format: 'YYYY-MM-DD HH:mm:ss'
        }), format.printf(info => `${info.timestamp} ${info.level}: ${info.message}` + (info.splat !== undefined ? `${info.splat}` : " "))
    ),
    transports: [
        transport,
        new (winston.transports.Console)({ json: false, timestamp: true }),
        //new winston.transports.File({ timestamp: true, filename: `${__folderName}/${_fileName}.log`, json: false })
    ],
    exceptionHandlers: [
        //new (winston.transports.Console)({ json: false, timestamp: true }),
        new winston.transports.File({ filename: __folderName + '/exceptions.log', json: false })
    ],
    exitOnError: false
});

var Logger = {
    prefix: '',
    postfix: '',
    saveFileType: { CSV: 'csv', JSON: 'json' },
    consoleLog: function (obj) {
        //pushNotificationServer.notifyClient(obj);
        winstonLogger.info(obj);
    },
    logError: function (obj) {
        //pushNotificationServer.notifyClient(obj,true);
        winstonLogger.error(obj);
    },
    saveDataToFile: function (list, filetype, loggingDirectory, fileName) {
        if (filetype === this.saveFileType.CSV) {
            return fileSaver.saveDataToCSVFile(list, loggingDirectory, fileName);
        } else if (filetype === this.saveFileType.JSON) {
            return fileSaver.saveDataToJSONFile(list, loggingDirectory, fileName);
        }
    }


}

module.exports = Logger;


