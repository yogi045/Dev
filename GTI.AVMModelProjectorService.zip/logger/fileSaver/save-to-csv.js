/**https://firstclassjs.com/how-to-convert-json-to-csv-in-node-js/ */
const csvjson = require('csvjson');
var moment = require('moment');
const writeFile = require('fs').writeFile;
const fs = require('fs');

var createFolderIfNotExist = function (dir) {

    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
        console.log(`${dir} created for logging`);
    }
}
var createFullPath = function (dir, fileExtention, fileName) {
    return `${dir}/${fileName}_${moment().format('DDMMYYYYHHmmss')}.${fileExtention}`;
}
var FileSaver = {
    saveDataToCSVFile: function (jsonData, loggingDirectory, fileName) {
        const csvData = csvjson.toCSV(jsonData, {
            headers: 'key'
        });

        //createFolderIfNotExist(loggingDirectory);
        fileName = createFullPath(loggingDirectory, 'csv', fileName);
        writeFile(fileName, csvData, (err) => {
            if (err) {
                console.log('error in csv file saver...'); // Do something to handle the error or just throw it
                console.log(err);
            }

            console.log('data saved to csv file!');
        });
        return fileName;
    },
    saveDataToJSONFile: function (jsonObj, loggingDirectory, fileName) {      
        // stringify JSON Object
        var jsonContent = JSON.stringify(jsonObj);
        fileName = createFullPath(loggingDirectory, 'json', fileName);
        fs.writeFile(fileName, jsonContent, 'utf8', function (err) {
            if (err) {                
                return console.log(err);
            }
        });
    }
}

module.exports = FileSaver;
