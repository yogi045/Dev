
class AppConfig {    
    static get timerInterVal() { return 60000; };
    static get ReportEmailDay() { return 4; };   
    static get ReportEmailTime() { return 20; };       
    static get LoggerFolderLocation() { return 'C:/Hemant_Data/EmailSend/Log' };  
    static get emailTemplateFileLocation() { return './emailHelper/mailTemplates' };
    static get emailAttachmentFileLocation() { return 'C:\\Yogesh_Data\\RISFile\\Email' };
    static get FromEMailAddress() { return 'yogesh.k.sharma@mmc.com' };
    static get ToEMailAddress() { return 'yogesh.k.sharma@mmc.com' };
    static get EmailNotificatinSubject() { return 'AutoServ |  requires your attention.' };
    static get SummaryEmailSubject() { return 'AutoServ | Daily summary of today\'s action' };
    static get SMTPSettings() {
        return {
            host: 'nasa2smtp.mmc.com',
            port: 25
        }
    }
    static get DBConnectionSettings() {
        return {
            user: 'svc-sonar',         
            password: ',tgKcm9REiOp2Sp',
            server: 'USDFW13DB46\\USDFW13DB46SI7',
            database: 'securitysonar',
            requestTimeout : 500000,
            connectionTimeout: 500000,
            pool: {
                max: 10,
                min: 0,
                evictionRunIntervalMillis: 10000,
                idleTimeoutMillis: 10000
            },
            options: {
                enableArithAbort: true,
                encrypt: true
            }
        }
    };
    static get SMTPSettings() {
        return {
            host: 'nasa2smtp.mmc.com',
            port: 25
        }
    }
}
module.exports = AppConfig;