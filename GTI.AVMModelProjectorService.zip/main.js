var EmailService = require("./services/service");
var StringHelper = require('./string-helper');

async function main() {  
    /*add custumize methods to string prototype */
     StringHelper.addExtentionMethods();    
    /*start the service */
    EmailService.start();   
}
main();