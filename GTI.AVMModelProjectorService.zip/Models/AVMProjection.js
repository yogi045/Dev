class AVMProjection {
    constructor(){
        this.ServerName,
        this.ApplicationName,
        this.Contacts,   
        this.Prediction,
        this.Current_Schedule_Hours,
        this.Current_Utilized_Hours
    }
}

module.exports = {
    AVMProjection: AVMProjection
}