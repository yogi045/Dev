var DBHelper = require('../dal/db-helper');
var getDataFromDB = require('../DBOperations/selectDataFromDB');
var logger = require('../logger/app-logger');
var smtpMailHelper = require("../emailHelper/sendEmail");
const { DateTime } = require('mssql');
var htmlEmailBodyGenerator =require('../emailHelper/html-helper/generate-email-body');

var applyBusinessLogic = {   
    sendAVMProjectedData: async function(){
       try{           
           var projectionData = await getDataFromDB.getAVMData();   
            if(projectionData)
            {
               // const htmlBody = htmlEmailBodyGenerator.createHtmlForMailBody(projectionData);
                // await smtpMailHelper.sendSummaryMail(htmlBody,projectionData);
                await smtpMailHelper.sendSummaryMail(projectionData);
            }     
       }
       catch(ex)
       {
         logger.logError(`error occored in sendTodaySummary method : ${ex}`);
       }

    }
}
module.exports = applyBusinessLogic;