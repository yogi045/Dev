
var StringHelper = {
    addExtentionMethods: function () {
        this.add_format();
    },
    add_format: function () {
        if (!String.prototype.format) {
            String.prototype.format = function () {
                var args = arguments;
                return this.replace(/{(\d+)}/g, function (match, number) {
                    return typeof args[number] != 'undefined'
                        ? args[number]
                        : match
                        ;
                });
            };
        }
    },
    convertDTtoCSV: function (obj) {
        var fileName = '';
        var header = '';
        Object.keys(obj).forEach(e => {
            console.log(e);
            header = header + e + '|'
        }
        );
        header=header.substr(0,header.lastIndexOf('|'));
        console.log(header)
    }
}
//StringHelper.convertDTtoCSV({ 'rowId': 1, 'ruleType': 1 });
//BotActionStatus.getActionStatus();
module.exports = StringHelper;