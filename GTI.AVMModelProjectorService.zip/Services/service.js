const AppConfig = require('../config/app-config');
var logger = require('../logger/app-logger');
const applyBusinessLogic = require('../controllers/applyBusinessLogic');
const { DateTime } = require('mssql');

let isBusy = false;
var EmailService = {
  start: function (obj) {
    startTimer();   
  }
}
var startTimer = function () {
  intervalFunc();
  setInterval(intervalFunc, AppConfig.timerInterVal);
}
function intervalFunc() {
  if (!isBusy) {
    var currectDate=new Date();
    var ReportDay = currectDate.getDay();
    var ReportTime=currectDate.getHours();
    logger.consoleLog(`\n timer tick trigger${logger.postfix}`);
    if(ReportDay==AppConfig.ReportEmailDay && (ReportTime==AppConfig.ReportEmailTime && ReportTime<AppConfig.ReportEmailTime+1))
    {
    start();    
    }  
    
  } else {
    logger.consoleLog(`${logger.prefix}timer invoked - rejected${logger.postfix}`);
  }
}
var start = async function () {
  try {
      console.log('start working');   
      isBusy =true; 
      await applyBusinessLogic.sendAVMProjectedData();
      isBusy= false;     
  }
  catch (ex) {   
    logger.logError(`error occored in start method : ${ex}`); 
  }
}
module.exports = EmailService;

