
const finalHtmlContent =
`<table style="size:11pt;font-family:'Calibri','sans-serif';border-collapse:collapse" border='0' cellspacing='0' cellpadding='0'>
<tbody>
 <tr valign='top' style='background:#004578;color:white'>
     <th style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>AVMName</th>
     <th style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>Cost</th>
     <th style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>PingCount</th>
     <th style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>Schedule</th>
     <th style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>ProjectedModel</th> 
     <th style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>HoursNeeded</th>
     <th style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>PotentiallySavings%</th> 
     <th style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>NewCost</th>      
 </tr>
 {0}     
</tbody>
</table>`;
const trSkeleton = `<tr valign='top' style='background-color:{0}'>
<td style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>{1}</td>
<td style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>{2}</td>
<td style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>{3}</td>
<td style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>{4}</td>
<td style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>{5}</td>
<td style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>{6}</td>
<td style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>{7}</td>
<td style='border:none;border-right:solid white 1.0pt;padding:1.45pt .05in 1.45pt .05in;font-family:Segoe UI, Helvetica Neue, Helvetica, Arial, Verdana;font-size:12px'>{8}</td>
</tr>`;

var HtmlEmailBody = {
createHtmlForMailBody: function (mailList) {
    let tr = ''
    mailList.forEach(function (obj) {	
        tr = tr + trSkeleton.format('#FFFFFF', obj.AVMName, obj.Cost, obj.PingCount, obj.Schedule,obj.ProjectedModel,obj.HoursNeeded,obj.PotentiallySavings, obj.NewCost);

    });

    return finalHtmlContent.format(tr);
}
}
module.exports = HtmlEmailBody;