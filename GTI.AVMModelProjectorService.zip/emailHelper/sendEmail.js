var nodemailer = require("nodemailer");
var logger = require("../logger/app-logger");
var fs = require('fs');
var AppConfig = require('../config/app-config');
const ObjectsToCsv = require('objects-to-csv')

const smtpSettingsObj=AppConfig.SMTPSettings;
let transport = nodemailer.createTransport({
    host: smtpSettingsObj.host,
    port: smtpSettingsObj.port,
    tls: {rejectUnauthorized: false}
});

var EmailSender = {    
    readTemplateHtml: async function (path) {
        return fs.readFileSync(path, 'utf8');
    },  
    sendSummaryMail: async function (objData) {
        try {
            let emailTemplatePath = '';
            var dataFile=`${AppConfig.emailAttachmentFileLocation}\\AVMModelProjection.csv`
            const message = {
                from: AppConfig.FromEMailAddress,
                to: AppConfig.ToEMailAddress, //AppConfig.ToEMailAddress
                subject: AppConfig.SummaryEmailSubject,
                html: '',
                attachments: [{filename: 'AVMModelProjection.csv',path: dataFile}]
            };
            const csv = new ObjectsToCsv(objData);
            await csv.toDisk(dataFile);
            emailTemplatePath = `${AppConfig.emailTemplateFileLocation}/body.html`;
            const readFilePromise = await this.readTemplateHtml(emailTemplatePath);
            const finalMailBody = readFilePromise.format(emailTemplatePath);
            message.html = finalMailBody;       
            await transport.sendMail(message);           

        }
        catch(ex){
            logger.logError(`error occored in sendSummaryMail method : ${ex}`);
        }
    }
}

module.exports = EmailSender; 