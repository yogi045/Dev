﻿using System;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Configuration;
using System.Linq;

namespace ConsoleApplication1
{
   public class Metrix_Encryption
    {

        public Metrix_Encryption()
        { }

        public object WebConfigurationManager { get; private set; }

        /// <summary>
        /// key byte array
        /// </summary>


        /// <summary>
        /// decrypt a string
        /// </summary>
        /// <param name="StringData"></param>
        /// <returns></returns>
        public string DecryptString(string StringData)
        {
            byte[] bytesData;

            //added for Cryptography: Hardcoded IV
            string[] keyByteString = WebConfigurationManager.AppSettings["keyb"].Split(',');
            byte[] keyb = keyByteString.Select(s => byte.Parse(s)).ToArray();

            string[] ivByteString = WebConfigurationManager.AppSettings["ivb"].Split(',');
            byte[] ivb = ivByteString.Select(s => byte.Parse(s)).ToArray();

            //Algorithm only takes byte strings, so you need to convert.
            bytesData = Convert.FromBase64String(StringData);

            Rijndael rijndael = new RijndaelManaged();
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, rijndael.CreateDecryptor(keyb, ivb), CryptoStreamMode.Write);

            try
            {
                cs.Write(bytesData, 0, bytesData.Length);
            }
            catch (Exception ex)
            {
                throw new Exception("Error while writing encrypted data to the \n" + ex.Message);
            }

            cs.FlushFinalBlock();
            cs.Close();

            System.Text.Encoding encoding = System.Text.Encoding.UTF8;
            return encoding.GetString(ms.ToArray());

        }

        /// <summary>
        /// encrypt a string
        /// </summary>
        /// <param name="StringData"></param>
        /// <returns></returns>
        public string EncryptString(string StringData)
        {


            byte[] bytesData;

            //added for Cryptography: Hardcoded IV
            string[] keyByteString = WebConfigurationManager.AppSettings["keyb"].Split(',');
            byte[] keyb = keyByteString.Select(s => byte.Parse(s)).ToArray();

            string[] ivByteString = WebConfigurationManager.AppSettings["ivb"].Split(',');
            byte[] ivb = ivByteString.Select(s => byte.Parse(s)).ToArray();

            bytesData = Encoding.UTF8.GetBytes(StringData);

            //Set up the stream that will hold the encrypted data.
            MemoryStream memStreamEncryptedData = new MemoryStream();

            Rijndael rijndael = new RijndaelManaged();
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, rijndael.CreateEncryptor(keyb, ivb), CryptoStreamMode.Write);

            try
            {
                //Encrypt the data, write it to the memory stream.
                cs.Write(bytesData, 0, bytesData.Length);
            }
            catch (Exception ex)
            {
                throw new Exception("Error while writing encrypted data to the \n" + ex.Message);
            }

            cs.FlushFinalBlock();
            cs.Close();

            // Send the data back as a string.
            return Convert.ToBase64String(ms.ToArray());

        }

    }


}
}
