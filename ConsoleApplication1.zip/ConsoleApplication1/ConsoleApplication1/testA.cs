﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace ConsoleApplication1
{
   public class testA
    {
       public List<TestB> abc
        {
            get;set;
        }
    }
    public class TestB:TestC
    {
        public string test
        {
            get;
        }
    }
    public class TestC
    {
        public string test1
        {
            get; set;
        }
    }

}
