﻿using System;
using System.Security.Cryptography;
using System.IO;
using System.Text;

namespace Mercer.Focus.BusinessObjects
{
    /// <summary>
    /// Summary description for Cryptography.
    /// </summary>
    public class Cryptography
    {
        public Cryptography()
        { }

        /// <summary>
        /// key byte array
        /// </summary>
        private byte[] keyb = {
                                        1,253,5,50,52,91,193,
                                        133,193,22,221,164,57,128,
                                        91,91,19,39,111,197,125,98,
                                        89,48,97,154,83,187,222,167,121,74
                                     };
        /// <summary>
        /// intailization vector byte array
        /// </summary>
        private byte[] ivb = {
                                        10,61,235,120,122,120,80,248,
                                        13,182,22,212,176,46,56,85
                                    };

        /// <summary>
        /// decrypt a string
        /// </summary>
        /// <param name="StringData"></param>
        /// <returns></returns>
        public string DecryptString(string StringData)
        {
            byte[] bytesData;


            //Algorithm only takes byte strings, so you need to convert.
            bytesData = Convert.FromBase64String(StringData);

            Rijndael rijndael = new RijndaelManaged();
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, rijndael.CreateDecryptor(keyb, ivb), CryptoStreamMode.Write);

            try
            {
                cs.Write(bytesData, 0, bytesData.Length);
            }
            catch (Exception ex)
            {
                throw new Exception("Error while writing encrypted data to the \n" + ex.Message);
            }

            cs.FlushFinalBlock();
            cs.Close();

            System.Text.Encoding encoding = System.Text.Encoding.UTF8;
            return encoding.GetString(ms.ToArray());

        }

        /// <summary>
        /// encrypt a string
        /// </summary>
        /// <param name="StringData"></param>
        /// <returns></returns>
        public string EncryptString(string StringData)
        {


            byte[] bytesData;

            bytesData = Encoding.UTF8.GetBytes(StringData);

            //Set up the stream that will hold the encrypted data.
            MemoryStream memStreamEncryptedData = new MemoryStream();

            Rijndael rijndael = new RijndaelManaged();
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, rijndael.CreateEncryptor(keyb, ivb), CryptoStreamMode.Write);

            try
            {
                //Encrypt the data, write it to the memory stream.
                cs.Write(bytesData, 0, bytesData.Length);
            }
            catch (Exception ex)
            {
                throw new Exception("Error while writing encrypted data to the \n" + ex.Message);
            }

            cs.FlushFinalBlock();
            cs.Close();

            // Send the data back as a string.
            return Convert.ToBase64String(ms.ToArray());

        }

    }


}

