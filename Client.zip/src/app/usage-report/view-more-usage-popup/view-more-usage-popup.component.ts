import { CollectionViewer } from '@angular/cdk/collections';
import { DataSource } from '@angular/cdk/table';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as Highcharts from 'highcharts';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { UsageDataService } from 'src/app/core/usage/usage-data.service';
import { UsageData } from 'src/app/model/usage-data';
import { ChartConfigs } from 'src/app/_helpers/ChartConfig';
import * as lodash from 'lodash';
import More from 'highcharts/highcharts-more';
import * as FileSave from 'file-saver';
import {MatSnackBar} from '@angular/material/snack-bar';
More(Highcharts);
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);
import Exporting from 'highcharts/modules/exporting';
import { HttpEventType } from '@angular/common/http';
import { stringify } from '@angular/compiler/src/util';
import { AppConfigService } from 'src/app/core/app-config.service';
Exporting(Highcharts);

@Component({
  selector: 'app-view-more-usage-popup',
  templateUrl: './view-more-usage-popup.component.html',
  styleUrls: ['./view-more-usage-popup.component.css']
})
export class ViewMoreUsagePopupComponent implements OnInit {
  Highcharts1: typeof Highcharts = Highcharts;
  chart1Options: Highcharts.Options;
  chartRef1: Highcharts.Chart;
  chartCallback1: Highcharts.ChartCallbackFunction = (chart) => {
    this.chartRef1 = chart;
  };
  colorOptions1 = []

  content;
  contentAll;

  firstRecordset;
  secondRecordset;


  displayedColumns: string[];
  dataSource: AppUsageDataSource;
  queryData: any;
  pageTitle = '';
  chartTitle = '';
  chartNo = 0;
  dataLoading = true;
  chartEndPoint = 0;
  chartMax = 5;
  public appList: string[] = [];
  showPagination: boolean=true;
  public objData: object;
  snackBarDuration: number=1000;
  snackBarMessage: string='';
  snackBarSuccessMessage: string='';
  snackBarFailedMessage: string='';

  constructor(private usageDataService: UsageDataService,public dialogRef: MatDialogRef<ViewMoreUsagePopupComponent>, @Inject(MAT_DIALOG_DATA) public data: any,
   public chartConfig: ChartConfigs,private _snackBar: MatSnackBar,private appConfig: AppConfigService) { 
    this.queryData = data;
    this.chartNo = this.queryData.chartNo;
    
    let appDetails = [...this.queryData.firstRecordset];

    if(this.chartNo==1){
      this.displayedColumns=['EntryDate', 'FirstEntry','LastEntry', 'AVMName', 'HostName', 'GSCCode'];
      appDetails.forEach(element => {
      this.appList.push(element.AVMName)
    });
    }
    // else if(this.chartNo==2){
    //   appDetails.forEach(element => {
    //     this.appList.push(element.GSCCode)
    //   });
    // }
    else if(this.chartNo==3){
      this.displayedColumns= ['Date', 'AVMName', 'HostName', 'GSCCode', 'Referrer','HttpStatus', 'Count'];
      appDetails.forEach(element => {
        this.appList.push(element.Description)
      });
    }

    if(this.appList.length<this.chartMax){
    this.chartMax=this.appList.length;
  }
    this.chartEndPoint = this.appList.length;
    this.dataSource = new AppUsageDataSource(this.usageDataService,this.appList);
    this.dataSource.loadHistoryData(this.queryData);
    this.colorOptions1 = this.queryData.colorOptions1;
    this.firstRecordset = this.queryData.firstRecordset;
    this.secondRecordset = this.queryData.secondRecordset;
     // data set to run the right table
     this.content = this.dataSource.clientSubject;

     // main data set to filter
     this.contentAll = this.dataSource.clientSubject;
 
     this.pageTitle = this.queryData.pageTitle;
     this.chartTitle = this.queryData.chartTitle;
    this.renderChart();
  }

  ngOnInit(): void {
    let config = this.appConfig.getConfig();
    this.snackBarMessage = config.DownloadCustomMessage;
    this.snackBarDuration = parseInt(config.SnackBarDuration);
    this.snackBarSuccessMessage= config.DownloadSuccess;
    this.snackBarFailedMessage= config.DownloadFail;
  }
  renderChart() {
    this.loadChart();
    // this to resize the chart according to the div
    setTimeout(() => {
      this.chartRef1.reflow();
    }, 10);
  }
  setFilenameonexport(e){
    e.exportTable('csv',{fileName:this.pageTitle});
   //console.log(e);
 }
 beginning() {
  let chart = this.chartRef1;
  //this.chartEndPoint =chart.series[0].data.length;
  let currentMin = chart.xAxis[0].getExtremes().min;
  if(currentMin!=0 && this.chartEndPoint > this.chartMax){
    chart.xAxis[0].setExtremes(0, this.chartMax-1);
    this.dataSource.loadHistoryData(this.queryData,0,this.chartMax-1);
  }
}

next() {
  let chart = this.chartRef1;
  let currentMin = chart.xAxis[0].getExtremes().min;
  let currentMax = chart.xAxis[0].getExtremes().max;
  //this.chartEndPoint =chart.series[0].data.length;
if(currentMax<this.chartEndPoint-1){
  chart.xAxis[0].setExtremes(currentMin + this.chartMax, currentMax + this.chartMax);
  this.dataSource.loadHistoryData(this.queryData,currentMin + this.chartMax,currentMax + this.chartMax);
  }
}

previous() {
  let chart = this.chartRef1;
  let currentMin = chart.xAxis[0].getExtremes().min;
  let currentMax = chart.xAxis[0].getExtremes().max;
  if(currentMin>0){
  chart.xAxis[0].setExtremes(currentMin - this.chartMax, currentMax - this.chartMax);
  this.dataSource.loadHistoryData(this.queryData,currentMin - this.chartMax,currentMax - this.chartMax);
  }
}

end() {
  let chart = this.chartRef1;
  let currentMax = chart.xAxis[0].getExtremes().max;
  let remaingElement= this.chartEndPoint%(this.chartMax);
  if(currentMax< this.chartEndPoint-1){
  //chart.xAxis[0].setExtremes(remaingElement==0?this.chartEndPoint-this.chartMax:this.chartEndPoint-remaingElement, this.chartEndPoint);
  if(remaingElement==0){
    chart.xAxis[0].setExtremes(this.chartEndPoint-this.chartMax,this.chartEndPoint-1);
  }
  else{
    //possible remainder values are 1 2 3 4. So possible difference will be in range 2-8. When range is > 4 set extremes by subtracting chartMax from chartEndpoint(i.e. total elements)
    let diff= (this.chartEndPoint+remaingElement)-(this.chartEndPoint-remaingElement);
    if(diff>4){
      chart.xAxis[0].setExtremes(this.chartEndPoint-(this.chartMax-1),this.chartEndPoint);
    }
    else{
      
      chart.xAxis[0].setExtremes(this.chartEndPoint-remaingElement,(this.chartEndPoint-remaingElement)+(this.chartMax-1));//if diff < 4 then maintain chart extremes in range of 0 to 4( i.e. chart Max)
    }
    
  }
  this.dataSource.loadHistoryData(this.queryData,remaingElement==0?this.chartEndPoint-this.chartMax:this.chartEndPoint-remaingElement, this.chartEndPoint);
}
}
 loadChart() {
  const dataMain = [];
  const dataDrilldown = [];
  var datatable = [];
  
  if (this.chartNo === 1) {
   this.firstRecordset.forEach((item, idx) => {
      dataMain.push({
        name: item.AVMName,
        y: item.Count,
        drilldown: item.AVMName,
        color: this.colorOptions1[idx]
      });
    });

    const groupped = lodash.groupBy(this.secondRecordset, function (o) {
      return o.AVMName as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        d.push([innertElem.GSCCode, innertElem.Count]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });
   }
   if(this.chartNo === 2){
    this.firstRecordset.forEach((item, idx) => {
      dataMain.push({
        name: item.GSCCode,
        y: item.TotalHit,
        drilldown: item.GSCCode,
        color: this.colorOptions1[idx]
      });
    });
    const groupped = lodash.groupBy(this.secondRecordset, function (o) {
      return o.GSCCode as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        // d.push([innertElem.Referrer!=null?innertElem.Referrer.substr(0,55):"", innertElem.TotalHit]);
        d.push([innertElem.AVMName, innertElem.TotalHit]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });
   }
   if(this.chartNo === 3){
    this.firstRecordset.forEach((item, idx) => {
      dataMain.push({
        name: item.Description,
        y: item.Count,
        drilldown: item.Description,
        color: this.colorOptions1[idx]
      });
    });

    const groupped = lodash.groupBy(this.secondRecordset, function (o) {
      return o.Description as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        d.push([innertElem.GSCCode, innertElem.Count]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });

   }
    this.chart1Options = {
      // Created pie chart using Highchart

      chart: {
        type: this.chartConfig.Type,
        height: 380,
        width: 300,
        options3d: {
          enabled: true
        }, style: {
          fontFamily: this.chartConfig.FontFamily
        },
        events: {
          drillup: function (e) {
            this.showPagination=true;
            this.content = this.contentAll;
          }.bind(this),
          drilldown: function(e){
            this.showPagination=false;
          }.bind(this),
          load: function () {
            this.xAxis[0].setExtremes(0, 4);
          }
        }
      },
      credits: {
        enabled: false
      },

      title: {
        text: this.chartTitle,
        style: {
          fontSize: this.chartConfig.HeadingFontSize,
          fontWeight: this.chartConfig.FontWeight
        }
      },
      xAxis: [
        {
          type: "category",
          minRange: this.chartMax>4?this.chartMax-1:this.chartMax,//check minRange if appList is less than 5
          labels: {
            formatter: function(){
              if(isNaN(this.value)){
                return this.value.toString();;
              }
              else{
                return "";
              }
            },
            style: {
              fontSize: this.chartConfig.SeriseFontSize
            }
          }
        }
      ],
      plotOptions: {
        series: {
          events: {
            click: function (event) {
              if (this.chartNo === 1) {
                if (this.chartRef1.drillUpButton) {
                  var x1 = lodash.filter(this.contentAll.value, function (f) {
                    if (f.AVMName == event.point.series.userOptions.id && f.GSCCode == event.point.name)
                      return f as [];
                  })
                  this.content = x1;

                }
                else {
                  var x2 = lodash.filter(this.contentAll.value, function (o) {
                    //console.log(o);
                    if (o.AVMName == event.point.name)
                      return o as [];
                  })

                  this.content = x2;
                }
              }
              else if (this.chartNo === 3) { 
                if (this.chartRef1.drillUpButton) {
                  var x1 = lodash.filter(this.contentAll.value, function (f) {
                    if (f.Description == event.point.series.userOptions.id && f.GSCCode == event.point.name)
                      return f as [];
                  })
                  this.content = x1;

                }
                else {
                  var x2 = lodash.filter(this.contentAll.value, function (o) {
                    if (o.Description == event.point.name)
                      return o as [];
                  })

                  this.content = x2;
                }

              }
              else if (this.chartNo === 4) { 
                if (this.chartRef1.drillUpButton) {
                  var x1 = lodash.filter(this.contentAll.value, function (f) {
                    if (f.AVMName == event.point.series.userOptions.id && f.GSCCode == event.point.name)
                      return f as [];
                  })
                  this.content = x1;
                }
                else {
                  var x2 = lodash.filter(this.contentAll.value, function (o) {
                    //console.log(o);
                    if (o.AVMName == event.point.name)
                      return o as [];
                  })

                  this.content = x2;
                }

              }
            }.bind(this),
            legendItemClick: function () {
                            return false;
                          }
          },
          dataLabels: {
            enabled: true,
            format: "{point.y}"
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat:
          '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
      },
      series: [{
        type: "bar",
        name: this.chartTitle,
        colorByPoint: true,
        data: dataMain
      }],

      drilldown: {
        series: dataDrilldown
      },
      exporting: {
        buttons: {
          contextButton: {
            enabled: false
          },

        }
      }
    };
  // Refresh the chart
  if (this.chartRef1) {
    this.chartRef1.redraw();
    this.chartRef1.reflow();
  }
  }
  
  downloadData(){
    let objUsage= {chartNo:this.queryData.chartNo, startDate: this.queryData.startDate, endDate:this.queryData.endDate, userName: this.queryData.userName};
    this.usageDataService.downloadAllUsageData(objUsage).subscribe((response)=>{
      // if(response.type === HttpEventType.DownloadProgress)
      // {
      //   console.log(response.total);
      //   console.log(response.loaded);
      // }
       if(response.type === HttpEventType.Response){
         if(response.ok){
          if(!!Object(response.body).length){
           this.exportToCSV(Object(response.body),this.pageTitle);
           this._snackBar.open(this.snackBarSuccessMessage,"Success",{panelClass:'info-snackbar', duration: this.snackBarDuration});
          }
          else if(!Object(response.body) || !Object(response.body).length)
            {
              this._snackBar.open("No Data.","Success",{panelClass:'info-snackbar', duration: this.snackBarDuration});
            }
          }
         else{
           this._snackBar.open(this.snackBarFailedMessage,"Failed",{panelClass:'failure-snackbar', duration: this.snackBarDuration});
         }
        }
    })
    this._snackBar.open(this.snackBarMessage,"Download Started",{panelClass:'info-snackbar', duration: this.snackBarDuration});
  }
/**
 * Creates an array of data to CSV. It will automatically generate a title row based on object keys.
 * @param rows array of data to be converted to CSV.
 * @param fileName filename to save as. 
 * @param columns array of object properties to convert to CSV. If skipped, then all object properties will be used for CSV.
 */
exportToCSV(rows: object[], fileName: string, columns?: string[]): string{
  if (!rows || !rows.length) {
    return;
  }

  const separator = ',';
    const keys = Object.keys(rows[0]).filter(k => {
      if (columns?.length) {
        return columns.includes(k);
      } else {
        return true;
      }
    });
    const csvContent =
      keys.join(separator) +
      '\n' +
      rows.map(row => {
        return keys.map(k => {
          let cell = row[k] === null || row[k] === undefined ? '' : row[k];
          cell = cell instanceof Date
            ? cell.toLocaleString()
            : cell.toString().replace(/"/g, '""');
          if (cell.search(/("|,|\n)/g) >= 0) {
            cell = `"${cell}"`;
          }
          return cell;
        }).join(separator);
      }).join('\n');
    this.savetoFile(csvContent, fileName+(Math.floor(Math.random() * 50000).toString())+".csv", "CSV");

}
/**
 * Saves the file on the client's machine via FileSaver library.
 * @param buffer The data that need to be saved.
 * @param fileName File name to save as.
 * @param fileType File type to save as.
 */
savetoFile(buffer: any, fileName: string, fileType: string): void{
  const data: Blob = new Blob([buffer], { type: fileType });
  FileSave.saveAs(data,fileName);
}
}
export class AppUsageDataSource implements DataSource<UsageData>{
  public clientSubject = new BehaviorSubject<UsageData[]>([]);
  public loadingSubject = new BehaviorSubject<boolean>(false);
  public totalRecordsSubject = new BehaviorSubject<number>(0);
  private hasRecordsSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  public totalRecords$ = new BehaviorSubject<number>(0);
  public noRecord$ = this.hasRecordsSubject.asObservable();
  private appList : string[] = [];
  private chartMax = 5;
  constructor(private usagetDataService: UsageDataService, private appNames: string[]) {
    this.appList=appNames;}
  connect(collectionViewer: CollectionViewer): Observable<UsageData[]> {
    return this.clientSubject.asObservable();
  }
  disconnect() {
    this.clientSubject.complete();
    this.loadingSubject.complete();
    this.hasRecordsSubject.complete();
    this.totalRecordsSubject.complete();
  }
  loadHistoryData(queryData,min=0,max=0){
    /*default min & max values*/
    if(min==0 && max==0){
      min=0;
      max=this.chartMax;
    }
    else{max=max+1;}

    this.loadingSubject.next(true);
    this.usagetDataService.getViewMoreUsageData(queryData.userName,
      queryData.startDate, queryData.endDate,queryData.chartNo,this.appList.slice(min,max)).pipe(catchError(() => of([])),
        finalize(() => {
          this.loadingSubject.next(false)
        })
      ).subscribe((reportChartdata) => {
        // console.log(reportChartdata);
        if (reportChartdata.length > 0) {

          this.totalRecords$ = reportChartdata[0].TotalRecords;

          this.hasRecordsSubject.next(true);
        }
        this.clientSubject.next(reportChartdata);
      });
  }
}
