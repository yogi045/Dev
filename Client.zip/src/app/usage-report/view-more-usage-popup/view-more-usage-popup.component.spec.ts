import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMoreUsagePopupComponent } from './view-more-usage-popup.component';

describe('ViewMoreUsagePopupComponent', () => {
  let component: ViewMoreUsagePopupComponent;
  let fixture: ComponentFixture<ViewMoreUsagePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMoreUsagePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMoreUsagePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
