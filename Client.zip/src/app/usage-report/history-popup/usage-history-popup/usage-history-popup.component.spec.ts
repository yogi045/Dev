import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsageHistoryPopupComponent } from './usage-history-popup.component';

describe('UsageHistoryPopupComponent', () => {
  let component: UsageHistoryPopupComponent;
  let fixture: ComponentFixture<UsageHistoryPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsageHistoryPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsageHistoryPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
