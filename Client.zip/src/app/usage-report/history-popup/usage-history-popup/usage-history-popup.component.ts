import { CollectionViewer } from '@angular/cdk/collections';
import { DataSource } from '@angular/cdk/table';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { UsageDataService } from 'src/app/core/usage/usage-data.service';
import { UsageData } from 'src/app/model/usage-data';

@Component({
  selector: 'app-usage-history-popup',
  templateUrl: './usage-history-popup.component.html',
  styleUrls: ['./usage-history-popup.component.css']
})
export class UsageHistoryPopupComponent implements OnInit {
  displayedColumns: string[];
  dataSource : AppDataSource;
  queryData: any;
  title = '';
  dataLoading = true;
  chartNo: number=0;
  showChart: boolean=false;
  constructor(private usageDataService: UsageDataService, public dialogRef: MatDialogRef<UsageHistoryPopupComponent>, @Inject(MAT_DIALOG_DATA) public data: any) { 
    this.queryData = data;
    this.chartNo= this.queryData.chartNo;
    if(this.chartNo==3){
      this.title = "All "+data.filter2 + " for " + data.filter1;
      this.displayedColumns = ['Date', 'AVMName', 'HostName', 'GSCCode', 'Referrer','HttpStatus', 'Count'];
    }
    else{
      this.displayedColumns = ['EntryDate', 'FirstEntry','LastEntry', 'AVMName', 'HostName', 'GSCCode'];
    }
    if(this.chartNo==1){
      this.title = "Usage history of " + data.filter1 + " on " + data.filter2;
    }
    else if(this.chartNo==2){
      this.title = "Usage history of " + data.filter2 + " on " + data.filter1;
    }
  }

setFilenameonexport(e){
    e.exportTable('csv',{fileName:this.title});
    //console.log(e);
  }
  ngOnInit(): void {
    this.dataSource = new AppDataSource(this.usageDataService);
    this.dataSource.loadHistoryData(this.queryData);
  }
  

}
export class AppDataSource implements DataSource<UsageData>{
  private clientSubject = new BehaviorSubject<UsageData[]>([]);
  public loadingSubject = new BehaviorSubject<boolean>(false);
  public totalRecordsSubject = new BehaviorSubject<number>(0);
  private hasRecordsSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  public totalRecords$ = new BehaviorSubject<number>(0);
  public noRecord$ = this.hasRecordsSubject.asObservable();

  constructor(private usageDataService: UsageDataService) { }
  
  connect(collectionViewer: CollectionViewer): Observable<UsageData[]> {
    return this.clientSubject.asObservable();
  }
  disconnect() {
    this.clientSubject.complete();
    this.loadingSubject.complete();
    this.hasRecordsSubject.complete();
    this.totalRecordsSubject.complete();
  }
  loadHistoryData(queryData) {
    this.loadingSubject.next(true);
    this.usageDataService.getPopupChartdata(queryData.filter1, queryData.filter2, queryData.chartNo, 
      queryData.startDate,queryData.endDate).pipe(catchError(() => of([])),
      finalize(() => {
        this.loadingSubject.next(false)
      })
    ).subscribe((reportChartdata) => {
      // console.log(reportChartdata);
      if (reportChartdata.length > 0) {
        //this.totalRecordsSubject.next(clients[0].TotalRecords);
        this.totalRecords$ = reportChartdata[0].TotalRecords;
        this.hasRecordsSubject.next(true);
      }
      this.clientSubject.next(reportChartdata);
    });
    //console.log(this.clientSubject.getValue());
  }
}
