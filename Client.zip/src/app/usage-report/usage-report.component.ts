import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import * as Highcharts from 'highcharts';
import { DateTime} from 'luxon';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { of } from 'rxjs/internal/observable/of';
import { catchError } from 'rxjs/internal/operators/catchError';
import { finalize } from 'rxjs/internal/operators/finalize';
import { MessageBox, MessageBoxButton, MessageBoxStyle } from '../core/message-box';
import { UsageDataService} from '../core/usage/usage-data.service';
import { UsageData } from '../model/usage-data';
import * as lodash from 'lodash';
import { ChartConfigs } from '../_helpers/ChartConfig';
import { ViewMoreUsagePopupComponent } from './view-more-usage-popup/view-more-usage-popup.component';
import { UsageHistoryPopupComponent } from './history-popup/usage-history-popup/usage-history-popup.component';

@Component({
  selector: 'app-usage-report',
  templateUrl: './usage-report.component.html',
  styleUrls: ['./usage-report.component.css']
})
export class UsageReportComponent implements OnInit {
  message: string;
  allow_outside_click;
  width = "500px";
  //#region  Chart Objects
  // Chart1
  Highcharts1: typeof Highcharts = Highcharts;
  chart1Options: Highcharts.Options;
  chartRef1: Highcharts.Chart;
  chartCallback1: Highcharts.ChartCallbackFunction = (chart) => {
    this.chartRef1 = chart;
  };
   // Chart2
  //  Highcharts2: typeof Highcharts = Highcharts;
  //  chart2Options: Highcharts.Options;
  //  chartRef2: Highcharts.Chart;
  //  chartCallback2: Highcharts.ChartCallbackFunction = (chart) => {
  //    this.chartRef2 = chart;
  //  };
 
   // Chart3
   Highcharts3: typeof Highcharts = Highcharts;
   chart3Options: Highcharts.Options;
   chartRef3: Highcharts.Chart;
   chartCallback3: Highcharts.ChartCallbackFunction = (chart) => {
     this.chartRef3 = chart;
   };
 
   // Chart4
  //  Highcharts4: typeof Highcharts = Highcharts;
  //  chart4Options: Highcharts.Options;
  //  chartRef4: Highcharts.Chart;
  //  chartCallback4: Highcharts.ChartCallbackFunction = (chart) => {
  //    this.chartRef4 = chart;
  //  };
  //#endregion
  
  // Holds chart data
  content;
  isLoading: boolean;
  formGroup: FormGroup;
  private clientSubject = new BehaviorSubject<UsageData[]>([]);
  public loadingSubject = new BehaviorSubject<boolean>(false);
  // Color 1 pallet array
  colorOptions1 = ["#0077A0", "#8246AF", "#00968F", "#004C6C", "#275D38"];

  // Color 2 pallet array
  colorOptions2 = ["#009DE0", "#003865", "#BED3E4", "#87A0C4", "#4E6287"];

  // Color 2 pallet array
  colorOptions3 = ["#00AC41", "#275D38", "#B896D4", "#8246AF", "#463282"];
  
  // Color 4 pallet array
   colorOptions4 = ["#009DE0", "#003865", "#BED3E4", "#87A0C4", "#4E6287"];

   maxDate= new Date();
   //minDate = new DateTime.local().minus({days:30}).toISO();

  constructor(private fb: FormBuilder, public dialog: MatDialog, private usageDataService: UsageDataService, public chartConfig: ChartConfigs) { 
    this.formGroup = this.fb.group({
      startDateCtrl: new FormControl(DateTime.local().minus({ days: 30 }).toISO(), Validators.required),
      endDateCtrl: new FormControl((new Date()).toISOString(), Validators.required),
      userNameCtrl: new FormControl(JSON.parse(localStorage.getItem('currentUser')).id)
      //userNameCtrl: new FormControl('MERCER\\gourav-keshwani')
    });
    this.loadData();
  }
  
  ngOnInit(): void {
  }
  showMore(un, sd, ed, cn, fs, ss, pt, ct, co): void {
    let dialogRef = this.dialog.open(ViewMoreUsagePopupComponent, {
      width: '100%',
      data: { userName: un, startDate: sd, endDate: ed, chartNo: cn, firstRecordset: fs, secondRecordset: ss, pageTitle: pt, chartTitle: ct, colorOptions1: co }
    });
  }
  showHistory(f1, f2, cn, sd, ed): void {
    let dialogRef = this.dialog.open(UsageHistoryPopupComponent, {
      width: '100%',
      data: { filter1: f1, filter2: f2, chartNo: cn, startDate: sd, endDate: ed }
    });
  }
  getChartData(sd, ed, un) {
    this.isLoading = true ;
    this.usageDataService.getAllUsageData(sd, ed, un).pipe(catchError(() => of([])),
      finalize(() => {
        this.isLoading = false ;
      })
    ).subscribe((usageData) => {
      this.clientSubject.next(usageData);
      this.content = JSON.parse(JSON.stringify(usageData));
      this.renderCharts();
    })
  }

  connect(): Observable<UsageData[]> {
    return this.clientSubject.asObservable();
  }
  disconnect() {
    this.clientSubject.complete();
    this.loadingSubject.complete();
  }
  
  loadData() {
    var changedstartDate= new Date(this.formGroup.get('startDateCtrl').value).toISOString();
    var changedendDate=new Date(this.formGroup.get('endDateCtrl').value).toISOString();
    if(changedstartDate>changedendDate)
    {
      this.message = "Start date can not be more than end date.";
      MessageBox.show(this.dialog, this.message, "Alert", "", MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
      this.width).subscribe();
    return;
    }
    // this.getChartData(
    //   new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
    //   new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
    //   this.formGroup.get('userNameCtrl').value);
    this.getChartData(
      DateTime.fromISO(changedstartDate).toFormat('yyyy-MM-dd'),
      DateTime.fromISO(changedendDate).toFormat('yyyy-MM-dd'),
      this.formGroup.get('userNameCtrl').value);
  }

  renderCharts() {
    this.loadChart1();
    //this.loadChart2();
    this.loadChart3();

    // this to resize the chart according to the div
    setTimeout(() => {
      //if chartRef are not null
      if(!this.chartRef1 && !this.chartRef3){
        this.chartRef1.reflow();
        //this.chartRef2.reflow();
        this.chartRef3.reflow();
      }
    }, 15);
  }

  loadChart1() {
    const dataMain = [];
    const dataDrilldown = [];

    this.content.recordsets[0].slice(0, 5).forEach((item, idx) => {
      dataMain.push({
        name: item.AVMName,
        y: item.Count,
        drilldown: item.AVMName,
        color: this.colorOptions1[idx]
      });
    });

    const groupped = lodash.groupBy(this.content.recordsets[1], function (o) {
      return o.AVMName as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        d.push([innertElem.GSCCode, innertElem.Count]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });

    this.chart1Options = {
      // Created pie chart using Highchart
      chart: this.chartConfig.ChartObj,
      credits: {
        enabled: false
      },

      title: {
        text: "Least Server Usage - Top 5",
        style: {
          fontSize: this.chartConfig.HeadingFontSize,
          fontWeight: this.chartConfig.FontWeight
        }
      },
      xAxis: [
        {
          type: "category",
          labels: {
            style: {
              fontSize: this.chartConfig.SeriseFontSize
            }
          }
        }
      ],
      plotOptions: {
        series: {
          events: {
            click: function (event) {              
              if (this.chartRef1.drillUpButton) {
                this.showHistory(event.point.options.name,
                  this.chartRef1.series[0].name,
                  1,
                  new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                  new Date(this.formGroup.get('endDateCtrl').value).toISOString());
              }
            }.bind(this),
            legendItemClick: function () {
                            return false;
                          } 
          },
          dataLabels: {
            enabled: true,
            format: "{point.y}"
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat:
          '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
      },
      series: [{
        type: "bar",
        name: "Server Usages",
        colorByPoint: true,
        data: dataMain
      }],

      drilldown: {
        series: dataDrilldown
      },
      exporting: {
        buttons: {
          contextButton: {
            enabled: false
          },
          customButton: {
            x: 10,
            y: -5,
            text: 'View More',
            onclick: function () {
              this.showMore(this.formGroup.get('userNameCtrl').value,
                new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
                1,
                this.content.recordsets[0], this.content.recordsets[1],
                "Server Usage - History",
                "Server Usage",
                this.colorOptions1);
            }.bind(this)
          }
        }
      }
    };
  }
  // loadChart2() {
  //   const dataMain = [];
  //   const dataDrilldown = [];

  //   this.content.recordsets[2].slice(0, 5).forEach((item, idx) => {
  //     dataMain.push({
  //       name: item.GSCCode,
  //       y: item.TotalHit,
  //       drilldown: item.GSCCode,
  //       color: this.colorOptions2[idx]
  //     });
  //   });

  //   const groupped = lodash.groupBy(this.content.recordsets[3], function (o) {
  //     return o.GSCCode as [];
  //   })

  //   // group and create drill data
  //   Object.keys(groupped).forEach(element => {
  //     var d = [];
  //     groupped[element].slice(0,5).forEach(innertElem => {
  //       // d.push([innertElem.Referrer!=null?innertElem.Referrer.substr(0,55):"", innertElem.TotalHit]);
  //       d.push([innertElem.AVMName, innertElem.TotalHit]);
  //     });

  //     dataDrilldown.push({
  //       name: element,
  //       id: element,
  //       data: d
  //     });
  //   });

  //   this.chart2Options = {
  //     // Created pie chart using Highchart
  //     chart: this.chartConfig.ChartObj,
  //     credits: {
  //       enabled: false
  //     },

  //     title: {
  //       text: "Least App Usage - Top 5",
  //       style: {
  //         fontSize: this.chartConfig.HeadingFontSize,
  //         fontWeight: this.chartConfig.FontWeight
  //       }
  //     },
  //     xAxis: [
  //       {
  //         type: "category",
  //         labels: {
  //           style: {
  //             fontSize: this.chartConfig.SeriseFontSize
  //           }
  //         }
  //       }
  //     ],
  //     plotOptions: {
  //       series: {
  //         events: {
  //           click: function (event) {              
  //             if (this.chartRef2.drillUpButton) {
  //               this.showHistory(event.point.options.name,
  //                 this.chartRef2.series[0].name,
  //                 2,
  //                 new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
  //                 new Date(this.formGroup.get('endDateCtrl').value).toISOString());
  //             }
  //           }.bind(this),
  //           legendItemClick: function () {
  //                           return false;
  //                         } 
  //         },
  //         dataLabels: {
  //           enabled: true,
  //           format: "{point.y}"
  //         }
  //       }
  //     },
  //     tooltip: {
  //       headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
  //       pointFormat:
  //         '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
  //     },
  //     series: [{
  //       type: "bar",
  //       name: "App Usage",
  //       colorByPoint: true,
  //       data: dataMain
  //     }],

  //     drilldown: {
  //       series: dataDrilldown
  //     },
  //     exporting: {
  //       buttons: {
  //         contextButton: {
  //           enabled: false
  //         },
  //         customButton: {
  //           // enabled: false,
  //           //To DO
  //           x: 10,
  //           y: -5,
  //           text: 'View More',
  //           onclick: function () {
  //             this.showMore(this.formGroup.get('userNameCtrl').value,
  //               new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
  //               new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
  //               2,
  //               this.content.recordsets[2], this.content.recordsets[3],
  //               "App Usage - History",
  //               "App Usage",
  //               this.colorOptions1);
  //           }.bind(this)
  //         }
  //       }
  //     }
  //   };
  // }
  loadChart3() {
    const dataMain = [];
    const dataDrilldown = [];

    this.content.recordsets[2].slice(0, 5).forEach((item, idx) => {
      dataMain.push({
        name: item.Description,
        y: item.Count,
        drilldown: item.Description,
        color: this.colorOptions3[idx]
      });
    });

    const groupped = lodash.groupBy(this.content.recordsets[3], function (o) {
      return o.Description as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        d.push([innertElem.GSCCode, innertElem.Count]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });

    this.chart3Options = {
      // Created pie chart using Highchart
      chart: this.chartConfig.ChartObj,
      credits: {
        enabled: false
      },

      title: {
        text: "Top 5 Errors",
        style: {
          fontSize: this.chartConfig.HeadingFontSize,
          fontWeight: this.chartConfig.FontWeight
        }
      },
      xAxis: [
        {
          type: "category",
          labels: {
            style: {
              fontSize: this.chartConfig.SeriseFontSize
            }
          }
        }
      ],
      plotOptions: {
        series: {
          events: {
            click: function (event) {              
              if (this.chartRef3.drillUpButton) {
                this.showHistory(event.point.options.name,
                  this.chartRef3.series[0].name,
                  3,
                  new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                  new Date(this.formGroup.get('endDateCtrl').value).toISOString());
              }
            }.bind(this),
            legendItemClick: function () {
                            return false;
                          } 
          },
          dataLabels: {
            enabled: true,
            format: "{point.y}"
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat:
          '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
      },
      series: [{
        type: "bar",
        name: "App Usage",
        colorByPoint: true,
        data: dataMain
      }],

      drilldown: {
        series: dataDrilldown
      },
      exporting: {
        buttons: {
          contextButton: {
            enabled: false
          },
          customButton: {
            x: 10,
            y: -5,
            text: 'View More',
            onclick: function () {
              this.showMore(this.formGroup.get('userNameCtrl').value,
                new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
                3,
                this.content.recordsets[2], this.content.recordsets[3],
                "Application Error - History",
                "App Error",
                this.colorOptions1);
            }.bind(this)
          }
        }
      }
    };
  }
}
