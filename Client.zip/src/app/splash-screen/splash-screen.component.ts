import { ChangeDetectorRef, Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { SplashAnimationType } from './splash-animation-types';

@Component({
  selector: 'splash-screen',
  templateUrl: './splash-screen.component.html',
  styleUrls: ['./splash-screen.component.css']
})
export class SplashScreenComponent implements OnInit {
  windowWidth: string;
  showSplash = true;
  
  constructor(private cd: ChangeDetectorRef) { }

  ngOnInit(): void {

  }

  hideSplash() {
    this.windowWidth = "-" + window.innerWidth + "px";
    setTimeout(() => {
      this.showSplash = !this.showSplash;
    }, 500);
  }
}
