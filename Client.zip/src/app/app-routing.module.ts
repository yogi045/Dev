import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AVMControlComponent } from './admin/avm-control/avm-control.component';
import {ApplicationListComponent} from './admin/createapplication/application-list.component';
import { AppDataComponent } from './app-data/app-data.component';
import {mychartComponent} from './reports/highchartReport.component';
import { UsageReportComponent } from './usage-report/usage-report.component';

const routes: Routes = [
  {path: '', redirectTo:"/schedules", pathMatch: "full"},
  {path: 'schedules', component:AppDataComponent},
  {path: 'dashboard', component: mychartComponent},
  {path: 'usage', component: UsageReportComponent},
  {path: 'AVMControl', component: AVMControlComponent},
  // {path: 'admin', component: ApplicationListComponent},
{ path: '**', redirectTo: '' }]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }