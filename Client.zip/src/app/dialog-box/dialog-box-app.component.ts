import { Component, Inject, Optional } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AppData } from '../model/appData.model';

@Component({
  selector: 'dialog-box-app',
  templateUrl: './dialog-box-app.component.html'
})
export class DialogBoxAppComponent {
  action:string;
  local_data:any;
  information: any;
  //@Optional() is used to prevent error if no data is passed
  constructor(public dialogRef: MatDialogRef<DialogBoxAppComponent>,@Optional() @Inject(MAT_DIALOG_DATA) public data: AppData) {
    this.local_data = {...data};
    this.action = this.local_data.action;
    this.information= this.local_data.information;
    }
    doAction(){
      this.dialogRef.close({event:this.action,data:this.local_data});
    }
    closeDialog(){
      this.dialogRef.close({event:'Cancel'});
    }
}
