import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogBoxAppComponent } from './dialog-box-app.component';

describe('DialogBoxClientComponent', () => {
  let component: DialogBoxAppComponent;
  let fixture: ComponentFixture<DialogBoxAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogBoxAppComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogBoxAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
