export class AppUser{
    name: string;
    id: string;
    hasAccess: boolean;
}