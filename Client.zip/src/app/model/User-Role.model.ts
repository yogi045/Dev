export class UserRoles{
    name: string;
    page: string;
    PagePath: string;
}