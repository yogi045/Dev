export class CasdData{
    SNo: number;
    CASDApplication: string;
    GSCName:string;
    AltAppName: string;
    ScheduleId:number;
    CreatedBy: string
}