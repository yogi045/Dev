import { UsageData } from './usage-data';

describe('UsageData', () => {
  it('should create an instance', () => {
    expect(new UsageData()).toBeTruthy();
  });
});
