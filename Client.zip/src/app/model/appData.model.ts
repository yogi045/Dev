export class AppData{
    SNo: number;
    AltAppName:string;
    CASDApplication: string;
    AVMName: string;
    Environment: string;
    GSCName:string;
    DefaultStartTime:Date;
    DefaultEndTime:Date;
    OnDefaultSchedule: boolean;
    ProposedStart: Date;
    ProposedEnd: Date;
    ESTProposedStart: Date;
    ESTProposedEnd: Date;
    CreatedBy: string;
    CreatedOn: Date;
    ChangeReason:string;
    Comments:string;
    UserName:string;
    ScheduleId:number;
    oldProposedStart: Date;
    oldProposedEnd: Date;
    OnDemand:number
}