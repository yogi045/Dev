export class ReportData{
    CASDApplication: string;
    AVMName: string;
    Environment: string;
    ProposedStartDate: Date;
    ProposedEndDate: Date;
    TotalChanges: number;
    ChartType:string;
    Requester:string;
    Reason:string
}