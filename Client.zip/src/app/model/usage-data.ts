export class UsageData {
    CASDApplication: string;
    AVMName: string;
    HostName: string;
    GSCCode: string;
    PageLink: string;
    EntryTime: Date;
    LoadTime: number;
    HttpStatus: number;
    TotalChanges: number;
}
