import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {CasdApplicationService} from '../../core/casd-application.service'
//import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import {DialogBoxAddAppComponent} from './dialog-box-add-app.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-createapplication',
  templateUrl: './application-list.component.html',
  styleUrls: ['./application-list.component.css']
})
export class ApplicationListComponent implements OnInit {
  dataSource: MatTableDataSource<CasdApplication>;
  //@ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[]= ['CASDApplication', 'GSCCode','AltName','action'];
  
  constructor(public dialog:MatDialog, private casdappService: CasdApplicationService) { }

  ngOnInit(): void {
    this.casdappService.getApplications().subscribe((results)=>{
      this.dataSource = new MatTableDataSource(results);
      //this.dataSource.paginator = this.paginator;
    })
  }
  
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  openDialog(action, obj) {
    obj.action = action;
    obj.CreatedBy = obj.UserName;
    
  const dialogRef = this.dialog.open(DialogBoxAddAppComponent, { width: "46em", height: "58em", data: obj });
}
}
export interface CasdApplication{
  SNo: Int32Array;
  CasdApplication: string;
  GscCode: string;
  AltName: string;
}
