import { Component, Inject, Optional } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CasdData } from '../../model/casdData.model'
import { FormControl, FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'dialog-box-app',
  templateUrl: './dialog-box-add-app.component.html',
  styleUrls: ['./dialog-box-add-app.component.css']
})
export class DialogBoxAddAppComponent {
  action:string;
  local_data:any;
  information: any;
  options: FormGroup;
  floatLabelControl = new FormControl('auto');
  //@Optional() is used to prevent error if no data is passed
  constructor(fb: FormBuilder, private dialogRef: MatDialogRef<DialogBoxAddAppComponent>,@Optional() @Inject(MAT_DIALOG_DATA) public data: CasdData) {
    // console.log(data);
    this.local_data = {...data};
    this.action = this.local_data.action;
    this.information= this.local_data.information;
    this.options = fb.group({
      
      floatLabel: this.floatLabelControl,
    });
    }
    doAction(){
      this.dialogRef.close({event:this.action,data:this.local_data});
    }
    closeDialog(){
      this.dialogRef.close({event:'Cancel'});
    }
}