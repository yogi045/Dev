import {  Component, OnInit, ViewChild, AfterViewInit, ChangeDetectionStrategy, EventEmitter, Output, DoCheck } from '@angular/core';
import {AVMServiceService} from '../../core/AVMControl/avm-service.service'
import { AppData } from "../../model/appData.model";
import { DataSource, CollectionViewer } from '@angular/cdk/collections';
import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject, of, interval, Subscription } from 'rxjs';
import { catchError, finalize, tap, debounce, map, distinctUntilChanged, pairwise } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { DialogBoxAppComponent } from '../../dialog-box/dialog-box-app.component';
import { FormControl, Validators, NgForm } from '@angular/forms';
import { MessageBox, MessageBoxButton, MessageBoxStyle } from '../../core/message-box';
import { AppUser } from '../../model/appUser.model';
import { AlertService } from '../../core/alert.service';
import { AlertComponent } from '../../alert/alert.component';
import { DateTime } from 'luxon';
import { AppConfigService } from '../../core/app-config.service';
import {MatSlideToggleModule,MatSlideToggleChange} from '@angular/material/slide-toggle';

@Component({
  selector: 'app-avm-control',
  templateUrl: './avm-control.component.html',
  styleUrls: ['./avm-control.component.css']
})
export class AVMControlComponent implements OnInit,AfterViewInit  {

  @Output() 
  dataLoadingFinished: EventEmitter<boolean> = new EventEmitter();  

  maxTimeSpan;
  title = "";//alert: title
  message = "";//alert: message
  information = "";//alert: add any information
  button;//alert: button type
  style;//alert: style
  allow_outside_click;
  width = "500px";
  isValidTimeSpan: boolean = true;
  dataSource: AppDataSource;
  subscriber: Subscription;
  duration=2; 

  constructor(public dialog: MatDialog,
    private AVMServiceService: AVMServiceService,
    private messageService: AlertService,
    private appConfig: AppConfigService) {
      this.subscriber = this.messageService.getMessage().subscribe(message => {
      MessageBox.show(this.dialog, message.text);
    });
  }

  ngOnInit(): void {
    let config = this.appConfig.getConfig();
    this.maxTimeSpan = config.MaxTimeSpan.days;
    this.dataSource = new AppDataSource(this.AVMServiceService);
  }
  ngAfterViewInit() {
    setTimeout(() => {
       this.loadAppData();
       //Hide Splash once data fetched
       this.dataSource.loading$.subscribe((value)=>{
         if(!value){
           this.dataLoadingFinished.emit(true);
         }
       })
     });
   }
   
   loadAppData() {
    this.dataSource.loadOnDemandAVM();
  }
  displayedColumns: string[] = ['AVMName', 'action'];

  onToggle(appData) {
    this.AVMServiceService.updateOnDemandAVM(appData).subscribe(() => this.loadAppData());
}
}
export class AppDataSource implements DataSource<AppData>{
  public clientSubject = new BehaviorSubject<AppData[]>([]);
  public loadingSubject = new BehaviorSubject<boolean>(true);
  public totalRecordsSubject = new BehaviorSubject<number>(0);
  private hasRecordsSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  public totalRecords$ = new BehaviorSubject<number>(0);
  public noRecord$ = this.hasRecordsSubject.asObservable();
  constructor(private AVMServiceService: AVMServiceService) { }
  
  connect(collectionViewer: CollectionViewer): Observable<AppData[]> {
    return this.clientSubject.asObservable();
  }
  disconnect() {
    this.clientSubject.complete();
    this.loadingSubject.complete();
    this.hasRecordsSubject.complete();
    this.totalRecordsSubject.complete();
  }

  loadOnDemandAVM() {
    this.loadingSubject.next(true);
    this.AVMServiceService.getOnDemandAVM().pipe(catchError(() => of([])),
      finalize(() => {
        this.loadingSubject.next(false);
        })
    ).subscribe((schedules) => {
      if (schedules.length > 0) {
        // this.totalRecordsSubject.next(clients[0].TotalRecords);
        this.totalRecords$ = schedules[0].TotalRecords;
        this.hasRecordsSubject.next(true);
      }
      schedules.forEach(item => {
        item.oldProposedStart = item.ProposedStart;
        item.oldProposedEnd = item.ProposedEnd;
      })
      this.clientSubject.next(schedules);
    });
    //console.log(this.clientSubject.getValue());     
  }
}