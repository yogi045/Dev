import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AVMControlComponent } from './avm-control.component';

describe('AVMControlComponent', () => {
  let component: AVMControlComponent;
  let fixture: ComponentFixture<AVMControlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AVMControlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AVMControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
