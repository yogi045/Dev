import { Component, OnInit, ViewChild } from '@angular/core';
import { AppUser } from './model/appUser.model';
import { Router } from '@angular/router';
import { AuthenticationService } from './core/authorize/authentication.service';
import { SplashScreenComponent } from './splash-screen/splash-screen.component';
import { UserRoles } from './model/User-Role.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  @ViewChild(SplashScreenComponent)
  childComponent: SplashScreenComponent;

  title = 'Resource Scheduler';
  hasAccess: boolean = false;
  currentUser: AppUser;
  isLoading = true;
  showColor: boolean = false;
  Pages:UserRoles[]= [];
  // splashCounter: number =0;

  constructor(public router: Router,
    private authenticationService: AuthenticationService) {
    // this.splashCounter =this.authenticationService.counter;
    this.authenticationService.login().subscribe(userData=>{
      if (userData) {
        this.currentUser = userData
        this.hasAccess = Boolean(this.currentUser.hasAccess);
        this.isLoading = false;

        if(!this.hasAccess){this.childComponent.hideSplash();}
      }
    })
    this.authenticationService.Roles().subscribe(userData=>{
      if (userData) {
    this.Pages=userData;
       
      }
    })
  }

  ngOnInit() {
    if (localStorage.getItem('currentUser')) {
      //if AppUser object has value will return true
      if (!!this.currentUser) {
       
        this.hasAccess =   Boolean(this.currentUser.hasAccess);
        this.isLoading = false;
      
      }
    }
  }
  onActivate(componentReference) {
    //if dataLoadingFinished property has value return true
    this.authenticationService.Roles().subscribe(userData=>{
      if (userData) {
        var result = userData.map(function(a) {return a.PagePath;});
        var a=result.indexOf(this.router.url);
        if(result.indexOf(this.router.url)<0)
        {
          this.hasAccess=false;
        }
     
      }
    })
    if(this.router.url === '/schedules' || this.router.url === '/')
    this.showColor = true;
    else
    this.showColor = false;

    if(!!componentReference.dataLoadingFinished){
    componentReference.dataLoadingFinished.subscribe((d) => {
      this.childComponent.hideSplash();
    });
  }

  }
}
