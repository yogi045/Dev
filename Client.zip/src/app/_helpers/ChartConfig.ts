import { Injectable } from '@angular/core';

@Injectable()
export class ChartConfigs {

    constructor(){}

    Type = 'bar';
    FontFamily = 'Calibri';
    FontWeight = 'bold';
    SeriseFontSize='0.8em';
    HeadingFontSize='1em';
    Height = '270';
    Width='410';

    ChartObj = {
        type: this.Type,
        height: this.Height,
        width: this.Width,
        options3d: {
          enabled: true
        }, style: {
          fontFamily: this.FontFamily
        }
      };
  }
  
  