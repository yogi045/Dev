import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReportDataService } from 'src/app/core/app-data/report-data.service';
import { catchError, finalize } from 'rxjs/operators';
import { of } from 'rxjs/internal/observable/of';
import { BehaviorSubject, Observable } from 'rxjs';
import { ReportData } from 'src/app/model/ReportData.model';
import { DataSource } from '@angular/cdk/table';
import { CollectionViewer } from '@angular/cdk/collections';

@Component({
  selector: 'app-history-popup',
  templateUrl: './history-popup.component.html',
  styleUrls: ['./history-popup.component.css']
})
export class HistoryPopupComponent implements OnInit {
  displayedColumns: string[] = ['CASDApplication', 'Environment', 'AVMName', 'Reason', 'totalHrs', 'comments', 'RequestedOn', 'Requestor'];
  displayedColumns1: string[] = ['Date', 'CASDApplication', 'AVMName', 'Region', 'VMCost', 'DiskCost', 'SharedCost'];
  dataSource : AppDataSource;
  queryData: any;
  title = '';
  dataLoading = true;
  chartNo: number=0;
  showChart: boolean=false;

  constructor(private reportDataService: ReportDataService, public dialogRef: MatDialogRef<HistoryPopupComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    this.queryData = data;
    this.chartNo= this.queryData.chartNo;
    if(this.chartNo==6){
      this.showChart=true;
      this.title = "Cost history for " + data.filter1 + " on " + data.filter2;
    }
    else if(this.chartNo==5){
      this.showChart=true;
      this.title = "Usage History for " + data.filter1 + " on " + data.filter2;
      this.displayedColumns1 = ['EntryDate', 'FirstEntry','LastEntry', 'AVMName', 'HostName', 'GSCCode'];
    }
    else{
      this.title = "Change history for " + data.filter1 + " on " + data.filter2;
    }
  }
  setFilenameonexport(e){
    e.exportTable('csv',{fileName:this.title});
    //console.log(e);
  }
  ngOnInit(): void {
    this.dataSource = new AppDataSource(this.reportDataService);
    this.dataSource.loadHistoryData(this.queryData);
  }
}

export class AppDataSource implements DataSource<ReportData>{
  private clientSubject = new BehaviorSubject<ReportData[]>([]);
  public loadingSubject = new BehaviorSubject<boolean>(false);
  public totalRecordsSubject = new BehaviorSubject<number>(0);
  private hasRecordsSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  public totalRecords$ = new BehaviorSubject<number>(0);
  public noRecord$ = this.hasRecordsSubject.asObservable();

  constructor(private reportDataService: ReportDataService) { }

  connect(collectionViewer: CollectionViewer): Observable<ReportData[]> {
    return this.clientSubject.asObservable();
  }
  disconnect() {
    this.clientSubject.complete();
    this.loadingSubject.complete();
    this.hasRecordsSubject.complete();
    this.totalRecordsSubject.complete();
  }

  loadHistoryData(queryData) {
    this.loadingSubject.next(true);
    this.reportDataService.getPopupChartdata(queryData.filter1, queryData.filter2, queryData.chartNo, 
      queryData.startDate,queryData.endDate).pipe(catchError(() => of([])),
      finalize(() => {
        this.loadingSubject.next(false)
      })
    ).subscribe((reportChartdata) => {
      // console.log(reportChartdata);
      if (reportChartdata.length > 0) {
        //this.totalRecordsSubject.next(clients[0].TotalRecords);
        this.totalRecords$ = reportChartdata[0].TotalRecords;
        this.hasRecordsSubject.next(true);
      }
      this.clientSubject.next(reportChartdata);
    });
    //console.log(this.clientSubject.getValue());
  }

}