
import { Component, OnInit, ViewChild, AfterViewInit, ChangeDetectionStrategy, ElementRef } from '@angular/core';
import { ReportDataService } from "../core/app-data/report-data.service";
import { DataSource, CollectionViewer } from '@angular/cdk/collections';
import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject, of, interval, Subscription } from 'rxjs';
import { catchError, finalize, tap, debounce, map } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { DetailTableDialog } from '../popup/popup.component';
import { DateTime } from 'luxon';
import { ReportData } from "../model/ReportData.model";
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as  Highcharts from 'highcharts';
import More from 'highcharts/highcharts-more';
More(Highcharts);
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);
import Exporting from 'highcharts/modules/exporting';
Exporting(Highcharts);

import NoDataToDispay from 'highcharts/modules/no-data-to-display';
NoDataToDispay(Highcharts);
import { MessageBox, MessageBoxButton, MessageBoxStyle } from '../core/message-box';
import * as lodash from 'lodash';
import { HistoryPopupComponent } from './popup/history-popup/history-popup.component';
import { ViewMorePopupComponent } from './popup/view-more-popup/view-more-popup.component';
import { ChartConfigs } from '../_helpers/ChartConfig';

@Component({
  selector: 'highchartReport',
  templateUrl: './highchartReport.component.html',
  styleUrls: ['./highchartReport.component.css']
})

export class mychartComponent implements OnInit {
 message;
 allow_outside_click;
  width = "500px";
   //#region  Chart Objects
  // Chart1
  Highcharts1: typeof Highcharts = Highcharts;
  chart1Options: Highcharts.Options;
  chartRef1: Highcharts.Chart;
  chartCallback1: Highcharts.ChartCallbackFunction = (chart) => {
    this.chartRef1 = chart;
  };
  // Chart2
  Highcharts2: typeof Highcharts = Highcharts;
  chart2Options: Highcharts.Options;
  chartRef2: Highcharts.Chart;
  chartCallback2: Highcharts.ChartCallbackFunction = (chart) => {
    this.chartRef2 = chart;
  };

  // Chart3
  Highcharts3: typeof Highcharts = Highcharts;
  chart3Options: Highcharts.Options;
  chartRef3: Highcharts.Chart;
  chartCallback3: Highcharts.ChartCallbackFunction = (chart) => {
    this.chartRef3 = chart;
  };

  // Chart4
  Highcharts4: typeof Highcharts = Highcharts;
  chart4Options: Highcharts.Options;
  chartRef4: Highcharts.Chart;
  chartCallback4: Highcharts.ChartCallbackFunction = (chart) => {
    this.chartRef4 = chart;
  };
  // Chart5
  Highcharts5: typeof Highcharts = Highcharts;
  chart5Options: Highcharts.Options;
  chartRef5: Highcharts.Chart;
  chartCallback5: Highcharts.ChartCallbackFunction = (chart) => {
    this.chartRef5 = chart;
  };

  // Chart6
  Highcharts6: typeof Highcharts = Highcharts;
  chart6Options: Highcharts.Options;
  chartRef6: Highcharts.Chart;
  chartCallback6: Highcharts.ChartCallbackFunction = (chart) => {
    this.chartRef6 = chart;
  };
  // Color 1 pallet array
  colorOptions1 = ["#0077A0", "#8246AF", "#00968F", "#004C6C", "#275D38"];

  // Color 2 pallet array
  colorOptions2 = ["#009DE0", "#003865", "#BED3E4", "#87A0C4", "#4E6287"];

  // Color 2 pallet array
  colorOptions3 = ["#00AC41", "#275D38", "#B896D4", "#8246AF", "#463282"];
  
  // Color 4 pallet array
   colorOptions4 = ["#009DE0", "#003865", "#BED3E4", "#87A0C4", "#4E6287"];

  //#endregion
  maxDate= new Date();
  // Holds chart data
  content;
  isLoading: boolean;
  
  private clientSubject = new BehaviorSubject<ReportData[]>([]);
  public loadingSubject = new BehaviorSubject<boolean>(false);

  formGroup: FormGroup;
  constructor(private reportDataService: ReportDataService, private fb: FormBuilder, public dialog: MatDialog, public chartConfig: ChartConfigs) {
    this.formGroup = this.fb.group({
      startDateCtrl: new FormControl(DateTime.local().minus({ days: 60 }).toISO(), Validators.required),
      endDateCtrl: new FormControl((new Date()).toISOString(), Validators.required),
      chartTypeCtrl: new FormControl('BYHITS'),
      userNameCtrl: new FormControl(JSON.parse(localStorage.getItem('currentUser')).id)
      //userNameCtrl: new FormControl('MERCER\\gourav-keshwani')
    });
    this.loadData();
  }
 
  getChartData(sd, ed, ct, un) {
    this.isLoading = true ;
    this.reportDataService.getallReportChartdata(sd, ed, ct, un).pipe(catchError(() => of([])),
      finalize(() => {
        this.isLoading = false ;
      })
    ).subscribe((reportChartdata) => {
      this.clientSubject.next(reportChartdata);
      this.content = JSON.parse(JSON.stringify(reportChartdata));
      this.renderCharts();
    })
  }

  showHistory(f1, f2, cn, sd, ed): void {
    let dialogRef = this.dialog.open(HistoryPopupComponent, {
      width: '100%',
      data: { filter1: f1, filter2: f2, chartNo: cn, startDate: sd, endDate: ed }
    });
  }


  showMore(un, sd, ed, cn, fs, ss, pt, ct, co): void {
    let dialogRef = this.dialog.open(ViewMorePopupComponent, {
      width: '100%',
      data: { userName: un, startDate: sd, endDate: ed, chartNo: cn, firstRecordset: fs, secondRecordset: ss, pageTitle: pt, chartTitle: ct, colorOptions1: co }
    });
  }
  loadData() {
    var changedstartDate= new Date(this.formGroup.get('startDateCtrl').value).toISOString();
    var changedendDate=new Date(this.formGroup.get('endDateCtrl').value).toISOString();
    if(changedstartDate>changedendDate)
    {
      this.message = "Start date can not be more than end date.";
      MessageBox.show(this.dialog, this.message, "Alert", "", MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
      this.width).subscribe();
    return;
    }
    this.getChartData(
      // new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
      // new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
      DateTime.fromISO(changedstartDate).toFormat('yyyy-MM-dd'),
      DateTime.fromISO(changedendDate).toFormat('yyyy-MM-dd'),
      this.formGroup.get('chartTypeCtrl').value,
      this.formGroup.get('userNameCtrl').value);

  }

  renderCharts() {
    this.loadChart1();
    this.loadChart2();
    this.loadChart3();
    this.loadChart4();
    this.loadChart5();
    this.loadChart6();


    // this to resize the chart according to the div
    setTimeout(() => {
      if(!this.chartRef1 && !this.chartRef2 && !this.chartRef3 && !this.chartRef4 && !this.chartRef5 && !this.chartRef6){
      this.chartRef1.reflow();
      this.chartRef2.reflow();
      this.chartRef3.reflow();
      this.chartRef4.reflow();
      this.chartRef5.reflow();
      this.chartRef6.reflow();
      }
      }, 10);
  }

  ngOnInit() {
  }

  connect(): Observable<ReportData[]> {
    return this.clientSubject.asObservable();
  }
  disconnect() {
    this.clientSubject.complete();
    this.loadingSubject.complete();
  }
  
  loadChart1() {
    const dataMain = [];
    const dataDrilldown = [];

    this.content.recordsets[0].slice(0, 5).forEach((item, idx) => {
      dataMain.push({
        name: item.CASDApplication,
        y: item.TotalChanges,
        drilldown: item.CASDApplication,
        color: this.colorOptions1[idx]
      });
    });

    const groupped = lodash.groupBy(this.content.recordsets[1], function (o) {
      return o.CASDApplication as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        d.push([innertElem.Environment, innertElem.TotalChanges]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });

    this.chart1Options = {
      // Created pie chart using Highchart
      chart: this.chartConfig.ChartObj,
      credits: {
        enabled: false
      },

      title: {
        text: "Top 5 Application Schedule Changes",
        style: {
          fontSize: this.chartConfig.HeadingFontSize,
          fontWeight: this.chartConfig.FontWeight
        }
      },
      xAxis: [
        {
          type: "category",
          labels: {
            style: {
              fontSize: this.chartConfig.SeriseFontSize
            }
          }
        }
      ],
      plotOptions: {
        series: {
          events: {
            click: function (event) {
              if (this.chartRef1.drillUpButton) {
                this.showHistory(this.chartRef1.series[0].name,
                  this.chartRef1.series[0].xAxis.names[0],
                  1,
                  new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                  new Date(this.formGroup.get('endDateCtrl').value).toISOString());
              }
            }.bind(this),
            legendItemClick: function () {
                            return false;
                          } 
          },
          dataLabels: {
            enabled: true,
            format: "{point.y}"
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat:
          '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
      },
      series: [{
        type: "bar",
        name: "Schedule Changes",
        colorByPoint: true,
        data: dataMain
      }],

      drilldown: {
        series: dataDrilldown
      },
      exporting: {
        buttons: {
          contextButton: {
            enabled: false
          },
          customButton: {
            x: 10,
            y: -5,
            text: 'View More',
            onclick: function () {
              this.showMore(this.formGroup.get('userNameCtrl').value,
                new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
                1,
                this.content.recordsets[0], this.content.recordsets[1],
                "Application Schedule Changes - History",
                "Application Schedule Changes",
                this.colorOptions1);
            }.bind(this)
          }
        }
      }
    };

    // Refresh the chart
    /*if (this.chartRef1) {
      this.chartRef1.redraw();
      this.chartRef1.reflow();
    }*/

  }

  loadChart2() {

    const dataMain = [];
    const dataDrilldown = [];

    this.content.recordsets[2].slice(0, 5).forEach((item, idx) => {
      dataMain.push({
        name: item.AVMName,
        y: item.TotalChanges,
        drilldown: item.AVMName,
        color: this.colorOptions2[idx]
      });
    });

    const groupped = lodash.groupBy(this.content.recordsets[3], function (o) {
      return o.AVMName as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        d.push([innertElem.CASDApplication, innertElem.TotalChanges]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });

    this.chart2Options = {
      // Created pie chart using Highchart
      chart: this.chartConfig.ChartObj,
      credits: {
        enabled: false
      },
      title: {
        text: "Top 5 AVM Duration Extension Changes",
        style: {
          fontSize: this.chartConfig.HeadingFontSize,
          fontWeight: this.chartConfig.FontWeight
        }
      },
      xAxis: [
        {
          type: "category",
          labels: {
            style: {
              fontSize: this.chartConfig.SeriseFontSize
            }
          }
        }
      ],
      plotOptions: {
        series: {
          events: {
            click: function (event) {
              if (this.chartRef2.drillUpButton) {
                this.showHistory(this.chartRef2.series[0].name, this.chartRef2.series[0].xAxis.names[0], 
                  2,                  
                  new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                  new Date(this.formGroup.get('endDateCtrl').value).toISOString());
              }
            }.bind(this),
            legendItemClick: function () {
                            return false;
                          } 
          },
          dataLabels: {
            enabled: true,
            format: "{point.y}"
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat:
          '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
      },
      series: [{
        type: "bar",
        name: "Extension Changes",
        colorByPoint: true,
        data: dataMain
      }],

      drilldown: {
        series: dataDrilldown
      },
      exporting: {
        buttons: {
          contextButton: {
            enabled: false
          },
          customButton: {
            x: 10,
            y: -5,
            text: 'View More',
            onclick: function () {
              this.showMore(this.formGroup.get('userNameCtrl').value,
                new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
                2,
                this.content.recordsets[2], this.content.recordsets[3],
                "AVM Duration Extension Changes - History",
                "AVM Duration Extension Changes",
                this.colorOptions2);
            }.bind(this)
          }
        }
      }
    };
  
  }

  loadChart3() {

    const dataMain = [];
    const dataDrilldown = [];

    this.content.recordsets[4].slice(0, 5).forEach((item, idx) => {
      dataMain.push({
        name: item.Requestor,
        y: item.TotalChanges,
        drilldown: item.Requestor,
        color: this.colorOptions3[idx]
      });
    });

    const groupped = lodash.groupBy(this.content.recordsets[5], function (o) {
      return o.Requestor as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        d.push([innertElem.CASDApplication, innertElem.TotalChanges]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });

    this.chart3Options = {
      // Created pie chart using Highchart
      chart: this.chartConfig.ChartObj,
      credits: {
        enabled: false
      },
      title: {
        text: "Top 5 Requestor Extension Changes",
        style: {
          fontSize: this.chartConfig.HeadingFontSize,
          fontWeight: this.chartConfig.FontWeight
        }
      },
      xAxis: [
        {
          type: "category",
          labels: {
            style: {
              fontSize: this.chartConfig.SeriseFontSize
            }
          }
        }
      ],
      plotOptions: {
        series: {
          events: {
            click: function (event) {
              if (this.chartRef3.drillUpButton) {
                this.showHistory(this.chartRef3.series[0].name,event.point.options.name, 3,
                  new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                  new Date(this.formGroup.get('endDateCtrl').value).toISOString());
              }
            }.bind(this),
            legendItemClick: function () {
                            return false;
                          } 
          },
          dataLabels: {
            enabled: true,
            format: "{point.y}"
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat:
          '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
      },
      series: [{
        type: "bar",
        name: "Requestor Changes",
        colorByPoint: true,
        data: dataMain
      }],

      drilldown: {
        series: dataDrilldown
      },
      exporting: {
        buttons: {
          contextButton: {
            enabled: false
          },
          customButton: {
            x: 10,
            y: -5,
            text: 'View More',
            onclick: function () {
              this.showMore(this.formGroup.get('userNameCtrl').value,
                new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
                3,
                this.content.recordsets[4], this.content.recordsets[5],
                "Requestor Extension Changes - History",
                "Requestor Extension Changes",
                this.colorOptions3);
            }.bind(this)
          }
        }
      }
    };
  }
  loadChart4() {

    const dataMain = [];
    const dataDrilldown = [];

    this.content.recordsets[6].slice(0, 5).forEach((item, idx) => {
      dataMain.push({
        name: item.Environment,
        y: item.TotalChanges,
        drilldown: item.Environment,
        color: this.colorOptions4[idx]
      });
    });

    const groupped = lodash.groupBy(this.content.recordsets[7], function (o) {
      return o.Environment as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        d.push([innertElem.CASDApplication, innertElem.TotalChanges]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });

    this.chart4Options = {
      // Created pie chart using Highchart
      chart: this.chartConfig.ChartObj,
      credits: {
        enabled: false
      },
      title: {
        text: "Top 5 Environment Extension Changes",
        style: {
          fontSize: this.chartConfig.HeadingFontSize,
          fontWeight: this.chartConfig.FontWeight
        }
      },
      xAxis: [
        {
          type: "category",
          labels: {
            style: {
              fontSize: this.chartConfig.SeriseFontSize
            }
          }
        }
      ],
      plotOptions: {
        series: {
          events: {
            click: function (event) {
              if (this.chartRef4.drillUpButton) {
                this.showHistory(this.chartRef4.series[0].name,event.point.options.name, 4,
                  new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                  new Date(this.formGroup.get('endDateCtrl').value).toISOString());
              }
            }.bind(this),
            legendItemClick: function () {
                            return false;
                          } 
          },
          dataLabels: {
            enabled: true,
            format: "{point.y}"
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat:
          '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
      },
      series: [{
        type: "bar",
        name: "Environment Changes",
        colorByPoint: true,
        data: dataMain
      }],

      drilldown: {
        series: dataDrilldown
      },
      exporting: {
        buttons: {
          contextButton: {
            enabled: false
          },
          customButton: {
            x: 10,
            y: -5,
            text: 'View More',
            onclick: function () {
              this.showMore(this.formGroup.get('userNameCtrl').value,
                new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
                4,
                this.content.recordsets[6], this.content.recordsets[7],
                "Environment Extension Changes - History",
                "Environment Extension Changes",
                this.colorOptions4);
            }.bind(this)
          }
        }
      }
    };
  }
  loadChart5() {

    const dataMain = [];
    const dataDrilldown = [];

    this.content.recordsets[8].slice(0, 5).forEach((item, idx) => {
      dataMain.push({
        name: item.GSCCode,
        y: item.TotalHit,
        drilldown: item.GSCCode,
        color: this.colorOptions2[idx]
      });
    });

    const groupped = lodash.groupBy(this.content.recordsets[9], function (o) {
      return o.GSCCode as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        d.push([innertElem.AVMName, innertElem.TotalHit]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });

    this.chart5Options = {
      // Created pie chart using Highchart
      chart: this.chartConfig.ChartObj,
      credits: {
        enabled: false
      },
      title: {
        text: "Least App Usage - Top 5",
        style: {
          fontSize: this.chartConfig.HeadingFontSize,
          fontWeight: this.chartConfig.FontWeight
        }
      },
      xAxis: [
        {
          type: "category",
          labels: {
            style: {
              fontSize: this.chartConfig.SeriseFontSize
            }
          }
        }
      ],
      plotOptions: {
        series: {
          events: {
            click: function (event) {
              if (this.chartRef5.drillUpButton) {
                this.showHistory(this.chartRef5.series[0].name,event.point.options.name, 5,
                  new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                  new Date(this.formGroup.get('endDateCtrl').value).toISOString());
              }
            }.bind(this),
            legendItemClick: function () {
                            return false;
                          } 
          },
          dataLabels: {
            enabled: true,
            format: "{point.y}"
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat:
          '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
      },
      series: [{
        type: "bar",
        name: "Server Usages",
        colorByPoint: true,
        data: dataMain
      }],

      drilldown: {
        series: dataDrilldown
      },
      exporting: {
        buttons: {
          contextButton: {
            enabled: false
          },
          customButton: {
            x: 10,
            y: -5,
            text: 'View More',
            onclick: function () {
              this.showMore(this.formGroup.get('userNameCtrl').value,
                new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
                5,
                this.content.recordsets[8], this.content.recordsets[9],
                "App Usage - History",
                "App Usage",
                this.colorOptions1);
            }.bind(this)
          }
        }
      }
    };
  
  }
  loadChart6(){
    const dataMain = [];
    const dataDrilldown = [];

    this.content.recordsets[10].slice(0, 5).forEach((item, idx) => {
      dataMain.push({
        name: item.CASDApplication,
        y: item.AppCost,
        drilldown: item.CASDApplication,
        color: this.colorOptions4[idx]
      });
    });

    const groupped = lodash.groupBy(this.content.recordsets[11], function (o) {
      return o.CASDApplication as [];
    })

    // group and create drill data
    Object.keys(groupped).forEach(element => {
      var d = [];
      groupped[element].forEach(innertElem => {
        d.push([innertElem.AVMName, innertElem.AppCost]);
      });

      dataDrilldown.push({
        name: element,
        id: element,
        data: d
      });
    });

    this.chart6Options = {
      // Created pie chart using Highchart
      chart: this.chartConfig.ChartObj,
      credits: {
        enabled: false
      },
      title: {
        text: "Top 5 App Cost",
        style: {
          fontSize: this.chartConfig.HeadingFontSize,
          fontWeight: this.chartConfig.FontWeight
        }
      },
      xAxis: [
        {
          type: "category",
          labels: {
            style: {
              fontSize: this.chartConfig.SeriseFontSize
            }
          }
        }
      ],
      plotOptions: {
        series: {
          events: {
            click: function (event) {
              if (this.chartRef6.drillUpButton) {
                this.showHistory(this.chartRef6.series[0].name,event.point.options.name, 6,
                  new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                  new Date(this.formGroup.get('endDateCtrl').value).toISOString());
              }
            }.bind(this),
            legendItemClick: function () {
                            return false;
                          } 
          },
          dataLabels: {
            enabled: true,
            format: "{point.y}"
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat:
          '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
      },
      series: [{
        type: "bar",
        name: "App Cost",
        colorByPoint: true,
        data: dataMain
      }],

      drilldown: {
        series: dataDrilldown
      },
      exporting: {
        buttons: {
          contextButton: {
            enabled: false
          },
          customButton: {
            x: 10,
            y: -5,
            text: 'View More',
            onclick: function () {
              this.showMore(this.formGroup.get('userNameCtrl').value,
                new Date(this.formGroup.get('startDateCtrl').value).toISOString(),
                new Date(this.formGroup.get('endDateCtrl').value).toISOString(),
                6,
                this.content.recordsets[10], this.content.recordsets[11],
                "Cost History All Applications",
                "App Cost",
                this.colorOptions1);
            }.bind(this)
          }
        }
      }
   };
  }
}