import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams, HttpHeaders } from '@angular/common/http';
import { AppData } from '../../model/appData.model';
import { Observable, throwError } from 'rxjs/index';
import {catchError, map} from "rxjs/operators";
import { DateTime } from 'luxon';
import { AppConfigService } from '../app-config.service';

const HTTP_SERVER_ERROR_CONNECTION_REFUSED = 'Connection refused';

@Injectable({
  providedIn: 'root'
})
export class AppDataService {
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  protected httpOptions = null;
  //private baseUrl: string = environment.apiURL;
  private baseUrl: string;
  constructor(private http: HttpClient,private appConfig: AppConfigService) { 
    this.baseUrl= appConfig.getConfig().apiURL;
  }
  
  protected getHttpOptions(params: HttpParams = null) {
    // this.logger.info('CollectionService: getHttpOptions()');
    if (!this.httpOptions) {
      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'}),
        params: null
      };
    }
    this.httpOptions.params = params;
    // this.logger.info(JSON.stringify(this.httpOptions));
    return this.httpOptions;
  }
  
  updateServerSchedule(appData: AppData):Observable<AppData> {

    // Prepare CST Time for the selected time
    var eD = DateTime.fromISO(new Date(appData.ProposedEnd).toISOString(),{zone:"America/Chicago"});
    var sD = DateTime.fromISO(new Date(appData.ProposedStart).toISOString(),{zone:"America/Chicago"});

    appData.ESTProposedEnd = eD;
    appData.ESTProposedStart = sD;

    return this.http.post<AppData>(this.baseUrl+'/updateSchedule', appData, {headers: this.headers}).pipe(
        catchError(err=>this.handleError(err)));
  }

  getServerSchedules(userName='',pageNumber = 1, pageSize = 5):  Observable<AppData[]> {
    return this.http.get<AppData[]>(this.baseUrl+'/getSchedules',{
      params: new HttpParams()
          .set('userName', userName.toString())
          .set('pageNumber', pageNumber.toString())
          .set('pageSize', pageSize.toString())
  }).pipe(
      catchError(err=>this.handleError(err))); 
}
  
/*getServerSchedules(userName='',pageNumber = 1, pageSize = 5):  Observable<AppData[]> {
  return this.http.get(this.baseUrl+'/getSchedules', {
      params: new HttpParams()
          .set('userName', userName)
          .set('pageNumber', pageNumber.toString())
          .set('pageSize', pageSize.toString())
  }).pipe(
      map(res => res["payload"])
  );
}*/

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something bad happened; please try again later.');
  };

}
