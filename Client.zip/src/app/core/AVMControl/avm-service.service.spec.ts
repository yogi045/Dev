import { TestBed } from '@angular/core/testing';

import { AVMServiceService } from './avm-service.service';

describe('AVMServiceService', () => {
  let service: AVMServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AVMServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
