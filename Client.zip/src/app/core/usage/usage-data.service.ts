import { HttpClient, HttpErrorResponse, HttpEvent, HttpHeaders, HttpParams } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import {catchError, map} from "rxjs/operators";
import { UsageData } from 'src/app/model/usage-data';
import { AppConfigService } from '../app-config.service';

const HTTP_SERVER_ERROR_CONNECTION_REFUSED = 'Connection refused';

@Injectable({
  providedIn: 'root'
})
export class UsageDataService {
  //private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  //protected httpOptions = null;
  //private baseUrl: string = environment.apiURL;
  private baseUrl: string;
  constructor(private http: HttpClient,private appConfig: AppConfigService) { 
    this.baseUrl= appConfig.getConfig().apiURL;
  }
  
  getAllUsageData(startDate='',endDate='',userName=''){
    return this.http.get<UsageData[]>(this.baseUrl+'/getAllUsageData',{
      params: new HttpParams()
          .set('ProposedStartDate', startDate.toString())
          .set('ProposedEndDate', endDate.toString())
          .set('userName', userName.toString())
  }).pipe(
      catchError(err=>this.handleError(err))); 
  }

  getPopupChartdata(Filter1 = '', Filter2 = '', chartNo = 1,startDate = '', endDate = ''): Observable<UsageData[]> {
    return this.http.get<UsageData[]>(this.baseUrl + '/getPopupUsage', {
      params: new HttpParams()
        .set('Filter1', Filter1.toString())
        .set('Filter2', Filter2.toString())
        .set('chartNo', chartNo.toString())
        .set('ProposedStartDate', startDate.toString())
        .set('ProposedEndDate', endDate.toString())
    }).pipe(
      catchError(err => this.handleError(err)));
  }

  getViewMoreUsageData(userName='',startDate='',endDate='',chartNo: number, appList: string[]){
    return this.http.get<UsageData[]>(this.baseUrl+'/getViewMoreUsage',{
      params: new HttpParams()
          .set('userName', userName.toString())
          .set('ProposedStartDate', startDate.toString())
          .set('ProposedEndDate', endDate.toString())
          .set('chartNo', chartNo.toString())
          .set('appNames', appList.toString())          
  }).pipe(
      catchError(err=>this.handleError(err))); 
  }
  
  downloadAllUsageData(data: object):Observable<HttpEvent<object>> {
    return this.http.post(this.baseUrl + '/downloadAllUsageData',data,
    {
      reportProgress: true,
      responseType: 'json',
      observe: 'events'
    }).pipe(
      catchError(err => this.handleError(err)));
  }
  
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something bad happened; please try again later.');
  };
}
