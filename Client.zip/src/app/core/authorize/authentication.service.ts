import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, pipe, throwError} from 'rxjs';
import { AppUser } from 'src/app/model/appUser.model';
import { AppConfigService } from '../app-config.service';
import {UserRoles} from 'src/app/model/User-Role.model'
import { HttpClient, HttpErrorResponse, HttpEvent, HttpHeaders, HttpParams } from '@angular/common/http';
import {catchError, map} from "rxjs/operators";
import { UsageData } from 'src/app/model/usage-data';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  //private baseUrl: string = environment.apiURL;
  public counter: number;
  private baseUrl: string;
  constructor(private http: HttpClient,private appConfig: AppConfigService) {
  this.baseUrl= appConfig.getConfig().apiURL;
  }
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something bad happened; please try again later.');
  };
  
  login(): Observable<AppUser>{
      return this.http.get<AppUser>(this.baseUrl+'/currentUser').pipe(
      map(user => {
        // store user details in local storage to keep user logged in between page refreshes
        localStorage.setItem('currentUser', JSON.stringify(user));
        return user;})); 
  }  
  Roles(): Observable<UserRoles[]>{
    return this.http.get<UserRoles[]>(this.baseUrl+'/getUserRoles').pipe(
      catchError(err=>this.handleError(err)));
    }
}
