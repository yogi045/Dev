import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpRequestInterceptor } from './_helpers/http-request.interceptor';
import { AppDataComponent } from './app-data/app-data.component';
import { DialogBoxAppComponent } from './dialog-box/dialog-box-app.component';
import { AppDataService } from './core/app-data/app-data.service';
import {AVMServiceService} from '../app/core/AVMControl/avm-service.service'
import { ReportDataService } from './core/app-data/report-data.service';
import { mychartComponent } from './reports/highchartReport.component';
import { HighchartsChartModule } from 'highcharts-angular';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTableModule } from '@angular/material/table';
import { MatTableExporterModule } from 'mat-table-exporter';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatPaginatorModule } from '@angular/material/paginator';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatGridListModule } from '@angular/material/grid-list';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';

import {
  NgxMatDatetimePickerModule,
  NgxMatNativeDateModule,
  NgxMatTimepickerModule
} from '@angular-material-components/datetime-picker';
import { AlertComponent } from './alert/alert.component';
import { AppConfigService } from './core/app-config.service';
import { ApplicationListComponent } from './admin/createapplication/application-list.component';
import { DialogBoxAddAppComponent } from './admin/createapplication/dialog-box-add-app.component';
import { HistoryPopupComponent } from './reports/popup/history-popup/history-popup.component';
import { ViewMorePopupComponent } from './reports/popup/view-more-popup/view-more-popup.component';

import { DetailTableDialog } from './popup/popup.component'
import { ChartConfigs } from './_helpers/ChartConfig';
import { SplashScreenComponent } from './splash-screen/splash-screen.component';
import { UsageReportComponent } from './usage-report/usage-report.component';
import { ViewMoreUsagePopupComponent } from './usage-report/view-more-usage-popup/view-more-usage-popup.component';
import { UsageHistoryPopupComponent } from './usage-report/history-popup/usage-history-popup/usage-history-popup.component';
import { AVMControlComponent } from './admin/avm-control/avm-control.component';

const appInitializerFn = (appConfig: AppConfigService) => {
  return () => {
    return appConfig.loadAppConfig();
  };
};

@NgModule({
  declarations: [
    AppComponent,
    AppDataComponent,
    DialogBoxAppComponent,
    AlertComponent,
    ApplicationListComponent,
    DialogBoxAddAppComponent,
    mychartComponent,
    HistoryPopupComponent,
    ViewMorePopupComponent,
    DetailTableDialog,
    SplashScreenComponent,
    UsageReportComponent,
    ViewMoreUsagePopupComponent,
    UsageHistoryPopupComponent,
    AVMControlComponent    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatTableModule,
    HttpClientModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatSidenavModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatNativeDateModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule,
    FormsModule,
    ReactiveFormsModule,
    HighchartsChartModule,
    MatButtonToggleModule,
    MatGridListModule,
    MatTableExporterModule,
    MatSlideToggleModule
  ],
  exports: [
    MatTableModule,
    MatPaginatorModule,
    MatSidenavModule,
    MatTableExporterModule,
    MatSnackBarModule,
    AlertComponent
  ],
  entryComponents: [DialogBoxAppComponent, AlertComponent, DialogBoxAddAppComponent, HistoryPopupComponent, ViewMorePopupComponent, ViewMoreUsagePopupComponent, UsageHistoryPopupComponent],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: HttpRequestInterceptor, multi: true },
    AppDataService, ReportDataService,
    AppConfigService, ChartConfigs,AVMServiceService,
    {
    provide: APP_INITIALIZER,
    useFactory: appInitializerFn,
    multi: true,
    deps: [AppConfigService]
  },
  {provide: LocationStrategy, useClass: HashLocationStrategy}
],
  bootstrap: [AppComponent]
})
export class AppModule { }
