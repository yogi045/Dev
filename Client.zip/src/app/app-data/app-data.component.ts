import { Component, OnInit, ViewChild, AfterViewInit, ChangeDetectionStrategy, EventEmitter, Output, DoCheck } from '@angular/core';
import { AppDataService } from "../core/app-data/app-data.service";
import { AppData } from "../model/appData.model";
import { DataSource, CollectionViewer } from '@angular/cdk/collections';
import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject, of, interval, Subscription } from 'rxjs';
import { catchError, finalize, tap, debounce, map, distinctUntilChanged, pairwise } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { DialogBoxAppComponent } from '../dialog-box/dialog-box-app.component';
import { FormControl, Validators, NgForm } from '@angular/forms';
import { MessageBox, MessageBoxButton, MessageBoxStyle } from '../core/message-box';
import { AppUser } from '../model/appUser.model';
import { AlertService } from '../core/alert.service';
import { AlertComponent } from '../alert/alert.component';
import { DateTime } from 'luxon';
import { AppConfigService } from '../core/app-config.service';
import { isNgTemplate } from '@angular/compiler';
import { SplashScreenComponent } from '../splash-screen/splash-screen.component';

@Component({
  selector: 'app-data',
  templateUrl: './app-data.component.html',
  styleUrls: ['./app-data.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppDataComponent implements AfterViewInit, OnInit {
 
  @Output() 
  dataLoadingFinished: EventEmitter<boolean> = new EventEmitter();  

  maxTimeSpan;
  title = "";//alert: title
  message = "";//alert: message
  information = "";//alert: add any information
  button;//alert: button type
  style;//alert: style
  allow_outside_click;
  width = "500px";
  isValidTimeSpan: boolean = true;
  dataSource: AppDataSource;
  subscriber: Subscription;
  duration=2;  
  
// 'SNo','GSCName',
  displayedColumns: string[] = ['CASDApplication', 'Environment', 'AVMName', 'DefaultStartTime', 'OnDefaultSchedule',
    'ProposedStart', 'ProposedEnd', 'CreatedBy', 'ChangeReason', 'Comments', 'action'];

  constructor(public dialog: MatDialog,
    private appDataService: AppDataService,
    private messageService: AlertService,
    private appConfig: AppConfigService) {
      this.subscriber = this.messageService.getMessage().subscribe(message => {
      MessageBox.show(this.dialog, message.text);
    });

    // this.control.valueChanges.pipe(distinctUntilChanged(),pairwise()
    // ).subscribe(([oldValue, newValue])=>{
    //   console.log(oldValue, newValue);
    //   this.oldValue=newValue;
    // })
    /** spinner starts on init */
    //this.spinner.show();

    // setTimeout(() => {
    //   /** spinner ends after 5 seconds */
    //   this.spinner.hide();
    // }, 5000);

  }
  
  ngOnInit() {
    let config = this.appConfig.getConfig();
    this.maxTimeSpan = config.MaxTimeSpan.days;
    this.dataSource = new AppDataSource(this.appDataService);
  }

  // ngDoCheck(){
    
  //   console.log( JSON.stringify(this.control));
  // }

  ngAfterViewInit() {
   setTimeout(() => {
      this.loadAppData();
      //Hide Splash once data fetched
      this.dataSource.loading$.subscribe((value)=>{
        if(!value){
          this.dataLoadingFinished.emit(true);
        }
      })
    });
  }

  loadAppData() {
    this.dataSource.loadServerSchedules(
      JSON.parse(localStorage.getItem('currentUser')).id,
      5,
      10);
  }

  getDateVal(date: string) {
    if (date == null) return "";

    var dt = new FormControl(new Date(date));
    //console.log(dt);
    return dt.value;
  }


  timeSpanValidation(proposedStart: any, proposedEnd: any) {
    this.message = '';
    this.information = '';
    proposedStart = new Date(proposedStart);
    proposedEnd = new Date(proposedEnd);
    this.isValidTimeSpan=true;
    let diffInDays = (proposedEnd.getTime() - proposedStart.getTime()) / (1000 * 3600 * 24);
    
    if (diffInDays > 1 && diffInDays <= this.maxTimeSpan) {
      this.information = "You are scheduling for more than 24 hrs";
      this.isValidTimeSpan = true;
      return;
    }
    if (proposedStart=='' || proposedStart.getFullYear()==1970)
    {
      this.message = `ProposedStart date is blank.`;
      this.width = (this.width !== undefined && this.width !== "px") ? this.width + "px" : "350px";

      this.isValidTimeSpan = false;
      return;
    }
    if (proposedEnd=='' || proposedEnd.getFullYear()==1970)
    {
      this.message = `ProposedEnd date is blank.`;
      this.width = (this.width !== undefined && this.width !== "px") ? this.width + "px" : "350px";

      this.isValidTimeSpan = false;
      return;
    }
    if (diffInDays > this.maxTimeSpan) {
      this.message = `Time Duration can not be more than ${this.maxTimeSpan} days`;
      this.width = (this.width !== undefined && this.width !== "px") ? this.width + "px" : "350px";

      this.isValidTimeSpan = false;
      return;
    }
  }

  addZero(a){
    if(a<10){
    a= "0" + a;
    }
    return a;
  }

  openDialog(action, obj, form: NgForm, index) {
   //console.log(obj);
   /** No need to check differences in time */
    let diffInDays = (((new Date(obj.ProposedEnd)).getTime()) - ((new Date(obj.ProposedStart)).getTime()))/(1000 * 3600 * 24);
      // let diffInDefaultTime = ((new Date("1/1/1990 " + obj.DefaultEndTime)).getTime()) - ((new Date("1/1/1990 " + obj.DefaultStartTime)).getTime());
      // let diffoldProposed = ((new Date(obj.oldProposedEnd)).getTime()) - ((new Date(obj.oldProposedStart)).getTime());
      //let defaultStartTime= new Date(obj.DefaultStartTime).getHours().toString() +":"+new Date(obj.DefaultStartTime).getMinutes().toString()+ ":"+ new Date(obj.DefaultStartTime).getSeconds().toString();
       let propsedStartTime= this.addZero(new Date(obj.ProposedStart).getHours()) +":"+this.addZero(new Date(obj.ProposedStart).getMinutes())+ ":"+ this.addZero(new Date(obj.ProposedStart).getSeconds());
       let proposedEndTime= this.addZero(new Date(obj.ProposedEnd).getHours()) +":"+this.addZero(new Date(obj.ProposedEnd).getMinutes())+ ":"+ this.addZero(new Date(obj.ProposedEnd).getSeconds());
    
    
    if(diffInDays<=1 && (propsedStartTime==obj.DefaultStartTime && proposedEndTime==obj.DefaultEndTime)){
      this.message = "You are trying to set server default schedule! Select a different time.";
      MessageBox.show(this.dialog, this.message, "Alert", this.information, MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
        this.width).subscribe();
      return;
    }
    if (this.isValidTimeSpan == false) {
      //  alert("Time Duration can not be more than 72 hrs");
      MessageBox.show(this.dialog, this.message, "Alert", this.information, MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
        this.width).subscribe();
      return;
    }
    if ((obj.OnDefaultSchedule == false || obj.OnDemand==1) && (!obj.ProposedStart || !obj.ProposedEnd || !obj.ChangeReason || !obj.Comments)) {
      //  alert("Please enter data in mandatory fields");
      this.message = "Please enter data in mandatory fields";
      MessageBox.show(this.dialog, this.message, "Error", this.information, MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
        this.width).subscribe();
      return;
    }
    else if ((obj.OnDefaultSchedule == false || obj.OnDemand==1) && obj.Comments.length < 11) {
      // alert("Comments cant be less than 10 characters");
      this.message = "Comments can't be less than 10 characters";
      MessageBox.show(this.dialog, this.message, "Alert", this.information, MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
        this.width).subscribe();
      return;
    }
    else if (obj.SNo>=1 && (obj.OnDefaultSchedule == false || obj.OnDemand==1) && new Date(obj.ProposedStart) < new Date()) {
      // alert("Proposed Start cant be less than todays date");
      this.message = "Proposed start cannot be less than current date and time";
      MessageBox.show(this.dialog, this.message, "Alert", this.information, MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
        this.width).subscribe();
      return;
    }
    else if ((obj.OnDefaultSchedule == false || obj.OnDemand==1) && new Date(obj.ProposedStart).toISOString() > new Date(obj.ProposedEnd).toISOString()) {
      // alert("Proposed Start cant be less than todays date");
      this.message = "Proposed end cannot be less than proposed start";
      MessageBox.show(this.dialog, this.message, "Alert", this.information, MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
        this.width).subscribe();
      return;
    }
    /** Code commented user is allowed to set schedule less than or equal to default time- Gourav Keshwani*/
    // else if (obj.OnDefaultSchedule == false && diffInProposedTime <= diffInDefaultTime) {
    //   this.message = "Proposed schedule can not be less than or same as the default schedule.";
    //   MessageBox.show(this.dialog, this.message, "Alert", this.information, MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
    //     this.width).subscribe();
    //   return;
    // }
    /** Commented as matching time difference is not correct logic. A new user shedule should accomadate any previously set user schedule.*/
    // else if (obj.OnDefaultSchedule == false && diffInProposedTime <= diffoldProposed) {
    //   this.message = "Existing proposed end time cannot be decreased.";
    //   MessageBox.show(this.dialog, this.message, "Alert", this.information, MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
    //     this.width).subscribe();
    //   return;

    // }
//   else if (obj.OnDefaultSchedule == false && (!!obj.oldProposedStart) && new Date(obj.ProposedStart).toISOString()> new Date(obj.oldProposedStart).toISOString()){
//     this.message = "Existing proposed start time cannot be increased.";
//     MessageBox.show(this.dialog, this.message, "Alert", this.information, MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
//       this.width).subscribe();
//     return;
// }
// else if(obj.OnDefaultSchedule == false && (!!obj.oldProposedEnd) && new Date(obj.ProposedEnd).toISOString()< new Date(obj.oldProposedEnd).toISOString()){
//   this.message = "Existing proposed end time cannot be decreased.";
//   MessageBox.show(this.dialog, this.message, "Alert", this.information, MessageBoxButton.Ok, this.allow_outside_click, MessageBoxStyle.Full,
//     this.width).subscribe();
//   return;
// }
    obj.action = action;
    obj.CreatedBy = obj.UserName;
    obj.information = this.information;

    const dialogRef = this.dialog.open(DialogBoxAppComponent, { width: "46em", height: "8em", data: obj });

    dialogRef.afterClosed().subscribe(result => {
      if (result.event == 'Update') {
        let txt = result.data.CASDApplication;
        if(result.data.Comments != null){
          result.data.Comments += result.data.Comments.search(txt)!=-1? "":"-" + result.data.CASDApplication;
        }
        this.dataSource.loadingSubject.next(true);
        this.appDataService.updateServerSchedule(result.data).subscribe(() => this.loadAppData());
      }
    });
  }

  isDisable(rowData) {
    if (rowData.OnDefaultSchedule == 0 || rowData.OnDemand==1) {
      return false;
    }
    return true;
  }
  getMindate() {
     var dat = DateTime.local().toLocaleString();
     var currenttime = (new Date).getHours() + ":" + (new Date).getMinutes() + ":" + (new Date).getSeconds();
    // //var time = currenttime < objt.DefaultStartTime ? currenttime : objt.DefaultStartTime;
    var mindt = (new Date(dat+" "+ currenttime)).toISOString();
    return mindt;

  }
  getCurrentDate() {
    return new Date();
  }
  onChecked(rowData)
  {
    if(rowData.OnDemand==1)
    {
      rowData.ProposedStart = null;
      rowData.ProposedEnd = null;
      rowData.ChangeReason = null;
      rowData.Comments = null;
      rowData.CreatedBy =null;
    }
  }

  clearValues(rowData) {
    var dt = DateTime.local().toLocaleString();
    if (rowData.OnDefaultSchedule) {
      rowData.ProposedStart = null;
      rowData.ProposedEnd = null;
      rowData.ChangeReason = null;
      rowData.Comments = null;
      rowData.CreatedBy =null;
      
    }
    else {
      rowData.ProposedStart = (new Date(dt + " " + rowData.DefaultStartTime)).toISOString();
      rowData.ProposedEnd = (new Date(dt + " " + rowData.DefaultEndTime)).toISOString();
      rowData.ChangeReason = null;
      rowData.Comments = null;
    }
  }
  
}

export class AppDataSource implements DataSource<AppData>{
  public clientSubject = new BehaviorSubject<AppData[]>([]);
  public loadingSubject = new BehaviorSubject<boolean>(true);
  public totalRecordsSubject = new BehaviorSubject<number>(0);
  private hasRecordsSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  public totalRecords$ = new BehaviorSubject<number>(0);
  public noRecord$ = this.hasRecordsSubject.asObservable();
  constructor(private appDataService: AppDataService) { }
  
  connect(collectionViewer: CollectionViewer): Observable<AppData[]> {
    return this.clientSubject.asObservable();
  }
  disconnect() {
    this.clientSubject.complete();
    this.loadingSubject.complete();
    this.hasRecordsSubject.complete();
    this.totalRecordsSubject.complete();
  }

  loadServerSchedules(userName = '', pageIndex = 1, pageSize = 5) {
    this.loadingSubject.next(true);
    this.appDataService.getServerSchedules(userName, pageIndex, pageSize).pipe(catchError(() => of([])),
      finalize(() => {
        this.loadingSubject.next(false);
        })
    ).subscribe((schedules) => {
      if (schedules.length > 0) {
        // this.totalRecordsSubject.next(clients[0].TotalRecords);
        this.totalRecords$ = schedules[0].TotalRecords;
        this.hasRecordsSubject.next(true);
      }
      schedules.forEach(item => {
        item.oldProposedStart = item.ProposedStart;
        item.oldProposedEnd = item.ProposedEnd;
      })
      this.clientSubject.next(schedules);
    });
    //console.log(this.clientSubject.getValue());     
  }
}