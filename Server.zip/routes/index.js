"use strict";
const sql = require("mssql");
const { poolPromise } = require('../dbconfig');
var passport = require('passport');
var { DateTime } = require('luxon');

module.exports.register = function(app) {

    app.get("/api/currentUser", passport.authenticate("WindowsAuthentication"), async function(req, res, next) {
        try {
            let userInfo = { name: req.headers['x-iisnode-auth_user'], id: req.headers['x-iisnode-auth_user'], hasAccess: false };
            //let userInfo={name:"mercer\\hitesh-basera",id:"mercer\\hitesh-basera"};
            let userName = userInfo.name;
            const pool = await poolPromise;
            const result = await pool.request().input('userName', sql.VarChar, userName)
                .query("Select Case WHEN count(1)>0 Then 1 ELSE 0 END as HasAccess from fn_getMappedUsers (@userName)");
            userInfo.hasAccess = result.recordset[0].HasAccess;
            res.status(200).json(userInfo);
        } catch (error) {
            next(error);
        }
    });

    app.get("/api/", (req, res) => {
        res.send("IIS Node! [Express Sample]");
    });

    app.get("/api/home", (req, res) => {
        res.send("Home Page IIS Node! [Express Sample]");
    });

    app.get("/api/getSchedules", async(req, res, next) => {
        try {
            let queryParams = req.query;
            let userName = queryParams.userName;
            let pageNumber = parseInt(queryParams.pageNumber) >= 0 ? parseInt(queryParams.pageNumber) : 0;
            let pageSize = parseInt(queryParams.pageSize) > 0 ? parseInt(queryParams.pageSize) : 5;
            const pool = await poolPromise;
            const result = await pool.request().input('userName', sql.VarChar, userName).input('pageNumber', sql.VarChar, pageNumber)
                .input('pageSize', sql.VarChar, pageSize)
                .query(`EXEC sp_getActiveSchedules @userName,@pageNumber,@pageSize`);
            res.json(result.recordset);

        } catch (error) {
            next(error);
        }
    });

    app.get("/api/getDateTime", async(req, res, next) => {
        var content = DateTime.fromISO(new Date().toISOString(), { zone: "America/Toronto" });
        content = content.plus({ minutes: DateTime.local().offset }); //add/subtract local time, to remove effect of UTC by DB server
        res.json(content);
    })

    app.post("/api/updateSchedule", async(req, res, next) => {
        try {

            var content = JSON.parse(JSON.stringify(req.body));
            let SerialNo = content.SNo;
            let applicationName = content.CASDApplication;
            let starttime = content.ProposedStart;
            let endTime = content.ProposedEnd;
            let proposedBy = content.CreatedBy;
            let reason = content.ChangeReason;
            let comments = content.Comments;
            let defaultSchedule = content.OnDefaultSchedule;
            let avmName = content.AVMName;
            let eststarttime = content.ESTProposedStart.slice(0, content.ESTProposedStart.lastIndexOf('-')) + 'Z';
            let estendtime = content.ESTProposedEnd.slice(0, content.ESTProposedEnd.lastIndexOf('-')) + 'Z';

            const pool = await poolPromise;
            const result = await pool.request().
            input('SerialNo', sql.VarChar, SerialNo).
            input('ApplicationName', sql.VarChar, applicationName).
            input('AVMName', sql.VarChar, avmName)
                .input('StartTime', sql.DateTime, starttime)
                .input('EndTime', sql.DateTime, endTime)
                .input('ESTStartTime', sql.DateTime, eststarttime)
                .input('ESTEndTime', sql.DateTime, estendtime)
                .input('ProposedBy', sql.VarChar, proposedBy).
            input('Reason', sql.VarChar, reason).input('Comments', sql.VarChar, (comments)).
            input('OnDefaultSchedule', sql.Bit, defaultSchedule).
            query(`EXEC sp_updateSchedule @SerialNo,@ApplicationName,@AVMName,@StartTime,@EndTime,@ESTStartTime,@ESTEndTime,@ProposedBy,@Reason,@Comments,@OnDefaultSchedule`);

            res.json(result.recordset);

        } catch (error) {
            next(error);
        }
    });

    app.get("/api/getAllApplications", async(req, res, next) => {
        try {
            const pool = await poolPromise;
            const result = await pool.request().query(`Select SNo,CASDApplication, GSCCode, AltAppName As AltName FROM tbl_CASD_Mapping Order By 2`);
            res.json(result.recordset);
        } catch (error) {
            next(error);
        }

    })   
    app.post("/api/UpdateOnDemandAVM", async(req, res, next) => {
        try {
            var content = JSON.parse(JSON.stringify(req.body));
            let AVMName = content.AVMName;
            let OnDenamdvalue = !content.OnDemand;
            const pool = await poolPromise;
            const result = await pool.request().
            input('AVMName', sql.VarChar, AVMName).
            input('OnDenamdvalue', sql.Bit, OnDenamdvalue).
            query(`EXEC sp_updateOnDemandAVM @AVMName,@OnDenamdvalue`);
            res.json(result.recordset);

        } catch (error) {
            next(error);
        }
    })  

    app.get("/api/getAVMData", async(req, res, next) => {
        try {
            const pool = await poolPromise;
            const result = await pool.request().query(`select distinct AVMName,isnull(OnDemand,0) as OnDemand from [tbl_CASD_AVM_Mapping] where isnull(AVMName,'')<>'' order by isnull(OnDemand,0) desc`);
            res.json(result.recordset);
        } catch (error) {
            next(error);
        }
    })  
    app.get("/api/getUserRoles",passport.authenticate("WindowsAuthentication"), async(req, res, next) => {
        try {
            let userInfo = { name: req.headers['x-iisnode-auth_user'], id: req.headers['x-iisnode-auth_user'] };
            //let userInfo={name:"mercer\\hitesh-basera",id:"mercer\\hitesh-basera"};
            let userName = userInfo.name;
            const pool = await poolPromise;
            const result = await pool.request().input('userName', sql.VarChar, userName).query(`sp_GetUserRoles @UserName`);
            res.json(result.recordset);
        } catch (error) {
            next(error);
        }
    })  
    
    app.get("/api/getallReportChartdata", async(req, res, next) => {
        try {
            let queryParams = req.query;
            let startDate = queryParams.ProposedStartDate;
            let endDate = queryParams.ProposedEndDate;

            let chartType = queryParams.ChartType;
            let userName = queryParams.userName;

            //    let startDate = '2020-06-01 07:07:39.510';
            //    let endDate='2020-09-23 07:07:39.510';

            //  let chartType='BYHITS';
            const pool = await poolPromise;
            const result = await pool.request().
            input('StartDate', sql.VarChar, startDate)
                .input('EndDate', sql.VarChar, endDate)
                .input('charttype', sql.VarChar, chartType)
                .input('userName', sql.VarChar, userName)
                .query('EXEC sp_getallReportChartdata @StartDate, @EndDate, @charttype,@userName');
            res.json(result);
        } catch (error) {
            next(error);
        }
    })
    app.get("/api/getPopupChartdata", async(req, res, next) => {
        try {
            //     var y = JSON.parse(JSON.stringify(req.body));
            //     let Filter1 = y.Filter1;//'PROJECT MANAGER';
            //     let Filter2=y.Filter2;//'Development';
            //    let chartNo=y.chartNo;

            let queryParams = req.query;

            let Filter1 = queryParams.Filter1; //'PROJECT MANAGER';
            let Filter2 = queryParams.Filter2; //'Development';
            let chartNo = queryParams.chartNo;
            let startDate = queryParams.ProposedStartDate;
            let endDate = queryParams.ProposedEndDate;

            // Filter1 = 'PROJECT MANAGER';
            // Filter2='Development';
            // chartNo=1;

            const pool = await poolPromise;
            const result = await pool.request().
            input('Filter1', sql.VarChar, Filter1)
                .input('Filter2', sql.VarChar, Filter2)
                .input('chartNo', sql.VarChar, chartNo)
                .input('StartDate', sql.VarChar, startDate)
                .input('EndDate', sql.VarChar, endDate)
                .query('EXEC sp_getPopupChartdata @Filter1, @Filter2, @chartNo,@StartDate,@EndDate');
            res.json(result.recordset);
        } catch (error) {
            next(error);
        }
    })

    app.get("/api/getviewMorePopupdata", async(req, res, next) => {
        try {
            let queryParams = req.query;

            let userName = queryParams.userName;
            let startDate = queryParams.ProposedStartDate;
            let endDate = queryParams.ProposedEndDate;
            let chartNo = queryParams.chartNo;
            let appList = queryParams.appNames;

            const pool = await poolPromise;
            const result = await pool.request().
            input('userName', sql.VarChar, userName)
                .input('StartDate', sql.VarChar, startDate)
                .input('EndDate', sql.VarChar, endDate)
                .input('chartNo', sql.VarChar, chartNo)
                .input('AppList', sql.VarChar,appList)
                .query('EXEC sp_getviewMorePopuptable @userName,@StartDate,@EndDate,@chartNo,@AppList');
            res.json(result.recordset);
        } catch (error) {
            next(error);
        }
    })

    app.get("/api/getAllUsageData", async(req,res, next)=>{
        try {
            let queryParams = req.query;

            let userName = queryParams.userName;
            let startDate = queryParams.ProposedStartDate;
            let endDate = queryParams.ProposedEndDate;
            
            const pool = await poolPromise;
            const result = await pool.request().
            input('userName', sql.VarChar, userName)
                .input('StartDate', sql.VarChar, startDate)
                .input('EndDate', sql.VarChar, endDate)
                .query('EXEC SP_GET_USAGE_DATA @userName,@StartDate,@EndDate');
            res.json(result);
        } catch (error) {
            next(error);
        }
    })

    app.get("/api/getViewMoreUsage", async(req, res, next)=>{
        try {
            let queryParams = req.query;

            let userName = queryParams.userName;
            let startDate = queryParams.ProposedStartDate;
            let endDate = queryParams.ProposedEndDate;
            let chartNo = queryParams.chartNo;
            let appList = queryParams.appNames;

            const pool = await poolPromise;
            const result = await pool.request().
            input('userName', sql.VarChar, userName)
                .input('StartDate', sql.VarChar, startDate)
                .input('EndDate', sql.VarChar, endDate)
                .input('chartNo', sql.VarChar, chartNo)
                .input('AppList', sql.VarChar,appList)
                .query('EXEC SP_GET_VIEW_MORE_USAGE_DATA @userName,@StartDate,@EndDate,@chartNo,@AppList');
            res.json(result.recordset);
        } catch (error) {
            next(error);
        }
    })

    app.get("/api/getPopupUsage", async(req, res, next)=>{
        try {
            let queryParams = req.query;

            let Filter1 = queryParams.Filter1; //'PROJECT MANAGER';
            let Filter2 = queryParams.Filter2; //'Development';
            let chartNo = queryParams.chartNo;
            let startDate = queryParams.ProposedStartDate;
            let endDate = queryParams.ProposedEndDate;

            const pool = await poolPromise;
            const result = await pool.request().
            input('Filter1', sql.VarChar, Filter1)
                .input('Filter2', sql.VarChar, Filter2)
                .input('chartNo', sql.VarChar, chartNo)
                .input('StartDate', sql.VarChar, startDate)
                .input('EndDate', sql.VarChar, endDate)
                .query('EXEC SP_GET_USAGE_POPUP @Filter1, @Filter2, @chartNo,@StartDate,@EndDate');
            res.json(result.recordset);
        } catch (error) {
            next(error);
        }
    })

    app.post("/api/downloadAllData", async(req,res,next)=>{
        try {
            let queryParams = req.body
             let userName = queryParams.userName;
             let chartNo = queryParams.chartNo;
             let startDate = queryParams.startDate;
             let endDate = queryParams.endDate;

            const pool = await poolPromise;
            const result = await pool.request()
                .input('UserName', sql.VarChar, userName)
                .input('chartNo', sql.VarChar, chartNo)
                .input('StartDate', sql.VarChar, startDate)
                .input('EndDate', sql.VarChar, endDate)
                .query('EXEC sp_GetAllData @chartNo,@StartDate,@EndDate,@UserName');
            res.json(result.recordset);

        } catch (error) {
            next(error)
        }
    })

    app.post("/api/downloadAllUsageData", async(req,res,next)=>{
        try {
            //let queryParams = req.query;
            let queryParams = req.body
             let userName = queryParams.userName;
             let chartNo = queryParams.chartNo;
             let startDate = queryParams.startDate;
             let endDate = queryParams.endDate;

             const pool = await poolPromise;
             const result = await pool.request()
                 .input('UserName', sql.VarChar, userName)
                 .input('chartNo', sql.VarChar, chartNo)
                 .input('StartDate', sql.VarChar, startDate)
                 .input('EndDate', sql.VarChar, endDate)
                 .query('EXEC sp_GetAllUsageData @chartNo,@StartDate,@EndDate,@UserName');
             res.json(result.recordset);
            //res.json(query);

        } catch (error) {
            next(error)
        }
    })
}