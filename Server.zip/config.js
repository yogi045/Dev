"use strict";
module.exports = {
    // port: PORT,
    // host: HOST,
    // url: HOST_URL,
    sql: {
        server: process.env.SQL_SERVER,
        database: process.env.SQL_DATABASE,
        user: process.env.SQL_USER,
        password: process.env.SQL_PASSWORD,
        requestTimeout: parseInt(process.env.REQUEST_TIMEOUT),
        pool: {
            max: parseInt(process.env.POOL_MAX),
            min: parseInt(process.env.POOL_MIN),
            idleTimeoutMillis: parseInt(process.env.POOL_IDLETIMEOUT)
        }
    }
};