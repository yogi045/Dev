"use strict";
const config = require('./config');
const express = require('express');
var passport = require('passport');
var WindowsStrategy = require('passport-windowsauth');
const bodyParser = require('body-parser');

var appRoutes= require('./routes');
const app = express();

app.use(bodyParser.json({ type: 'application/*+json' }));//parse various different custom JSON types as JSON
app.use(express.json()) // for parsing application/json
app.use(express.urlencoded({ extended: true })) // for parsing application/x-www-form-urlencoded
app.use(function(req, res, next) {
    res.header('Access-Control-Allow-Credentials', true);
    res.header('Access-Control-Allow-Origin', req.headers.origin);
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With, X-HTTP-Method-Override, Content-Type, Accept');
    next();
    });

    passport.serializeUser(function(user, done) {
            done(null, user);
        });
        
      passport.deserializeUser(function(user, done) {
        done(null, user);
      });
      
      passport.use(new WindowsStrategy({
        integrated: true 
      }, function(profile, done){
         if(profile){
            let user=profile;
            done(null,user);
          }
          else{
            return done(null, false);
            
          }
        }));

app.use(passport.initialize());
app.use(passport.session());

app.sqlConfig= config.sql;
appRoutes.register(app);
 
app.listen(process.env.PORT, () =>
  console.log(`Express Server listening on port ${process.env.port}!`),
);

module.exports = app;